declare module "@salesforce/resourceUrl/NDAStd3b" {
    var NDAStd3b: string;
    export default NDAStd3b;
}