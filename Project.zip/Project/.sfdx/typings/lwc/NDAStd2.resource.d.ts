declare module "@salesforce/resourceUrl/NDAStd2" {
    var NDAStd2: string;
    export default NDAStd2;
}