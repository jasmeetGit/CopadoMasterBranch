declare module "@salesforce/resourceUrl/BnP_RedFlag" {
    var BnP_RedFlag: string;
    export default BnP_RedFlag;
}