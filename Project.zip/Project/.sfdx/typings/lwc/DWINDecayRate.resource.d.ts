declare module "@salesforce/resourceUrl/DWINDecayRate" {
    var DWINDecayRate: string;
    export default DWINDecayRate;
}