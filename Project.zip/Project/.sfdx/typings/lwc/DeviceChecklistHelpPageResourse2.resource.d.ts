declare module "@salesforce/resourceUrl/DeviceChecklistHelpPageResourse2" {
    var DeviceChecklistHelpPageResourse2: string;
    export default DeviceChecklistHelpPageResourse2;
}