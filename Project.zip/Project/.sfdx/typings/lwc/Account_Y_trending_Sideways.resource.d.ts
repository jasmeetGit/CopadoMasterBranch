declare module "@salesforce/resourceUrl/Account_Y_trending_Sideways" {
    var Account_Y_trending_Sideways: string;
    export default Account_Y_trending_Sideways;
}