declare module "@salesforce/resourceUrl/geoImage_10nm" {
    var geoImage_10nm: string;
    export default geoImage_10nm;
}