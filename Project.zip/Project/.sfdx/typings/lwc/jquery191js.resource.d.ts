declare module "@salesforce/resourceUrl/jquery191js" {
    var jquery191js: string;
    export default jquery191js;
}