declare module "@salesforce/resourceUrl/MPWRelatedCSS" {
    var MPWRelatedCSS: string;
    export default MPWRelatedCSS;
}