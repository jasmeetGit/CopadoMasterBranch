declare module "@salesforce/resourceUrl/DS_Other_expired_stage6b" {
    var DS_Other_expired_stage6b: string;
    export default DS_Other_expired_stage6b;
}