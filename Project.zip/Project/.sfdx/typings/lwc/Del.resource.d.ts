declare module "@salesforce/resourceUrl/Del" {
    var Del: string;
    export default Del;
}