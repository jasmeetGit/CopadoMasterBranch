declare module "@salesforce/resourceUrl/MPWECCNTemplate" {
    var MPWECCNTemplate: string;
    export default MPWECCNTemplate;
}