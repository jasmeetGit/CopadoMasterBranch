declare module "@salesforce/resourceUrl/Account_Progress_2" {
    var Account_Progress_2: string;
    export default Account_Progress_2;
}