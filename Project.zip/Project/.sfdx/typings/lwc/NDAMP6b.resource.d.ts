declare module "@salesforce/resourceUrl/NDAMP6b" {
    var NDAMP6b: string;
    export default NDAMP6b;
}