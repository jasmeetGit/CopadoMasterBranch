declare module "@salesforce/resourceUrl/jQueryStatus" {
    var jQueryStatus: string;
    export default jQueryStatus;
}