declare module "@salesforce/resourceUrl/DS_Std_2_DSGroup_Stage3" {
    var DS_Std_2_DSGroup_Stage3: string;
    export default DS_Std_2_DSGroup_Stage3;
}