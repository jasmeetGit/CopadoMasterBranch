declare module "@salesforce/resourceUrl/dtButton" {
    var dtButton: string;
    export default dtButton;
}