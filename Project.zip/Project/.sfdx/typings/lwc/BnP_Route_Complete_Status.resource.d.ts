declare module "@salesforce/resourceUrl/BnP_Route_Complete_Status" {
    var BnP_Route_Complete_Status: string;
    export default BnP_Route_Complete_Status;
}