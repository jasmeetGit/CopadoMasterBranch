declare module "@salesforce/resourceUrl/NDAMPStageNew1" {
    var NDAMPStageNew1: string;
    export default NDAMPStageNew1;
}