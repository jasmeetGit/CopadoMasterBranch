declare module "@salesforce/resourceUrl/NewFV2Styles" {
    var NewFV2Styles: string;
    export default NewFV2Styles;
}