declare module "@salesforce/resourceUrl/DRCStatus" {
    var DRCStatus: string;
    export default DRCStatus;
}