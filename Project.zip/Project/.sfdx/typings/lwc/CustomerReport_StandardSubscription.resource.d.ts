declare module "@salesforce/resourceUrl/CustomerReport_StandardSubscription" {
    var CustomerReport_StandardSubscription: string;
    export default CustomerReport_StandardSubscription;
}