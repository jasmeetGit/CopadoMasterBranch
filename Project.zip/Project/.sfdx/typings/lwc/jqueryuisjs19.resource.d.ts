declare module "@salesforce/resourceUrl/jqueryuisjs19" {
    var jqueryuisjs19: string;
    export default jqueryuisjs19;
}