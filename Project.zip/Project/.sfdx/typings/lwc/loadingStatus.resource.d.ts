declare module "@salesforce/resourceUrl/loadingStatus" {
    var loadingStatus: string;
    export default loadingStatus;
}