declare module "@salesforce/resourceUrl/geoImage_gt180nm" {
    var geoImage_gt180nm: string;
    export default geoImage_gt180nm;
}