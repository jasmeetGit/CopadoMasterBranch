declare module "@salesforce/resourceUrl/GMPL_Partial_Support" {
    var GMPL_Partial_Support: string;
    export default GMPL_Partial_Support;
}