declare module "@salesforce/resourceUrl/GDSTemplate" {
    var GDSTemplate: string;
    export default GDSTemplate;
}