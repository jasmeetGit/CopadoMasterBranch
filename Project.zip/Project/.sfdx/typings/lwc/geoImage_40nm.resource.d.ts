declare module "@salesforce/resourceUrl/geoImage_40nm" {
    var geoImage_40nm: string;
    export default geoImage_40nm;
}