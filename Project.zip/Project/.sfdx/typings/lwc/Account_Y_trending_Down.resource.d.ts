declare module "@salesforce/resourceUrl/Account_Y_trending_Down" {
    var Account_Y_trending_Down: string;
    export default Account_Y_trending_Down;
}