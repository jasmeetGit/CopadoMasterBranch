declare module "@salesforce/resourceUrl/jQuery1_10_1" {
    var jQuery1_10_1: string;
    export default jQuery1_10_1;
}