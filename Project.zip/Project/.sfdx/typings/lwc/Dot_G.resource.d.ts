declare module "@salesforce/resourceUrl/Dot_G" {
    var Dot_G: string;
    export default Dot_G;
}