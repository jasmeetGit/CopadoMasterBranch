declare module "@salesforce/resourceUrl/JS_PSPpages" {
    var JS_PSPpages: string;
    export default JS_PSPpages;
}