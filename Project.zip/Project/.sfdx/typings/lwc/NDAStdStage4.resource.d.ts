declare module "@salesforce/resourceUrl/NDAStdStage4" {
    var NDAStdStage4: string;
    export default NDAStdStage4;
}