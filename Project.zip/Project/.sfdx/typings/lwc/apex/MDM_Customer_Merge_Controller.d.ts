declare module "@salesforce/apex/MDM_Customer_Merge_Controller.MDMCustomerMergeSplitMessages" {
  export default function MDMCustomerMergeSplitMessages(): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.profileValidation" {
  export default function profileValidation(param: {accId: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.getAccounts" {
  export default function getAccounts(param: {baseAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.getAccountsForSplit" {
  export default function getAccountsForSplit(param: {baseAccountId: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.getRelatedRecords" {
  export default function getRelatedRecords(param: {cmsReq: any, accList: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.getDeviceWrapper" {
  export default function getDeviceWrapper(param: {selectedOpportunities: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.getERPDevices" {
  export default function getERPDevices(param: {selectedOpportunities: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.searchAccountList" {
  export default function searchAccountList(param: {searchAccountName: any, baseAccountRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.searchContactList" {
  export default function searchContactList(param: {searchContactName: any, totalContactIds: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.searchOpportunityList" {
  export default function searchOpportunityList(param: {searchOpportunityName: any, totalOpportunityIds: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.updateCMSRObject" {
  export default function updateCMSRObject(param: {CMRSRequestSA: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.mergeAccounts" {
  export default function mergeAccounts(param: {baseAccountId: any, mergeAccount: any, mergeSplitDate: any, isRequestDetailsCompleted: any, buttonStr: any, contactIds: any, contactNames: any, onlyFile: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.saveChunk" {
  export default function saveChunk(param: {parentId: any, fileName: any, base64Data: any, contentType: any, fileId: any, description: any}): Promise<any>;
}
declare module "@salesforce/apex/MDM_Customer_Merge_Controller.deleteAttachment" {
  export default function deleteAttachment(param: {description: any, parentId: any}): Promise<any>;
}
