declare module "@salesforce/apex/TOMSMaintenanceController.getfabTechGeo" {
  export default function getfabTechGeo(): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.getMaskshopVendor" {
  export default function getMaskshopVendor(): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.searchMSVendor" {
  export default function searchMSVendor(param: {vendor: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.getMaskshopAlias" {
  export default function getMaskshopAlias(): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.createMSRecord" {
  export default function createMSRecord(param: {newRecord: any, fabTechGeoData: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.updateMSRecord" {
  export default function updateMSRecord(param: {updateRecord: any, fabTechGeoData: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.getMSRecord" {
  export default function getMSRecord(param: {maskshopId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.readAllFabAndTechGeo" {
  export default function readAllFabAndTechGeo(): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.readMaskshop" {
  export default function readMaskshop(): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.readMaskshopById" {
  export default function readMaskshopById(param: {maskshopId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.readMaskshopHelper" {
  export default function readMaskshopHelper(param: {maskshopList: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.readMaskshopWithFilter" {
  export default function readMaskshopWithFilter(param: {filterData: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSMaintenanceController.deleteMaskshops" {
  export default function deleteMaskshops(param: {maskshops: any}): Promise<any>;
}
