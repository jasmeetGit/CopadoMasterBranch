declare module "@salesforce/apex/OpportunityDetailPageController.getOpp" {
  export default function getOpp(param: {oppid: any}): Promise<any>;
}
