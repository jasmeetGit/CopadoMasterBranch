declare module "@salesforce/apex/CustomerReports_UtilityClass.getAccList" {
  export default function getAccList(): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_UtilityClass.getAccList" {
  export default function getAccList(param: {isCustomer: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_UtilityClass.isCustomer" {
  export default function isCustomer(): Promise<any>;
}
