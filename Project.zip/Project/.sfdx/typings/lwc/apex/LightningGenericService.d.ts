declare module "@salesforce/apex/LightningGenericService.executeQuery" {
  export default function executeQuery(param: {soqlString: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningGenericService.saveSObject" {
  export default function saveSObject(param: {record: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningGenericService.getCurrentUser" {
  export default function getCurrentUser(): Promise<any>;
}
declare module "@salesforce/apex/LightningGenericService.getUserProfile" {
  export default function getUserProfile(): Promise<any>;
}
declare module "@salesforce/apex/LightningGenericService.requestAccountConversion" {
  export default function requestAccountConversion(param: {leadId: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningGenericService.getOpportunityStage" {
  export default function getOpportunityStage(param: {opportunityId: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningGenericService.getOpportunityByOpportunityProgramId" {
  export default function getOpportunityByOpportunityProgramId(param: {opportunityProgramId: any}): Promise<any>;
}
