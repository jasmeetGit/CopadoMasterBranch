declare module "@salesforce/apex/TOFTRFPageController.getFTRFForm" {
  export default function getFTRFForm(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getFieldLabelsMessagesPrototype" {
  export default function getFieldLabelsMessagesPrototype(param: {formType: any, page: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getChipDetails" {
  export default function getChipDetails(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getConfigTableMap" {
  export default function getConfigTableMap(param: {page: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getChangedFields" {
  export default function getChangedFields(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getButtonValidations" {
  export default function getButtonValidations(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.deleteFtrfForm" {
  export default function deleteFtrfForm(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.updateFtrfBeol" {
  export default function updateFtrfBeol(param: {ftrfId: any, beolChipCount: any, beolChipTypeValue: any, fieldUpdateString: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.formTypeValue" {
  export default function formTypeValue(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.createTapeoutServiceRecord" {
  export default function createTapeoutServiceRecord(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.cloneForm" {
  export default function cloneForm(param: {tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getSObjectList" {
  export default function getSObjectList(): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.qualifiedUpdate" {
  export default function qualifiedUpdate(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getQualifiedFields" {
  export default function getQualifiedFields(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.createRetrofitRecord" {
  export default function createRetrofitRecord(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.createMaskLayerRecords" {
  export default function createMaskLayerRecords(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getMaskLayerRecords" {
  export default function getMaskLayerRecords(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getMaskLayerRecordsForCount" {
  export default function getMaskLayerRecordsForCount(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getMaskLayerRecordsList" {
  export default function getMaskLayerRecordsList(param: {ftrfId: any, isPassivation: any, passivationValue: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getRetroFormRecords" {
  export default function getRetroFormRecords(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getMaskLayersWithMDRCStatus" {
  export default function getMaskLayersWithMDRCStatus(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.validateCreateRetrofitRecord" {
  export default function validateCreateRetrofitRecord(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getMDRCRecordsCount" {
  export default function getMDRCRecordsCount(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.checkMDRCAccess" {
  export default function checkMDRCAccess(): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getLoggedInUserInfo" {
  export default function getLoggedInUserInfo(): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getAccessSetupDetails" {
  export default function getAccessSetupDetails(): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getFTRFformStatus" {
  export default function getFTRFformStatus(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getTapeoutServiceFormDetails" {
  export default function getTapeoutServiceFormDetails(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.getCustomSettingLables" {
  export default function getCustomSettingLables(param: {nameOfCS: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFPageController.showDeselectLayer" {
  export default function showDeselectLayer(param: {formId: any}): Promise<any>;
}
