declare module "@salesforce/apex/CurrentUserInfoController.fetchUser" {
  export default function fetchUser(): Promise<any>;
}
declare module "@salesforce/apex/CurrentUserInfoController.TaskCount" {
  export default function TaskCount(): Promise<any>;
}
