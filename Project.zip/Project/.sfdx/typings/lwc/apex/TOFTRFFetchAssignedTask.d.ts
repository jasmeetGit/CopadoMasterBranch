declare module "@salesforce/apex/TOFTRFFetchAssignedTask.taskDetails" {
  export default function taskDetails(param: {taskId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFFetchAssignedTask.getAllTask" {
  export default function getAllTask(): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFFetchAssignedTask.getWorkflowHistory" {
  export default function getWorkflowHistory(param: {formId: any}): Promise<any>;
}
