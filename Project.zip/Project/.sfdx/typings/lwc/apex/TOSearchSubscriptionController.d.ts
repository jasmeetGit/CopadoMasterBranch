declare module "@salesforce/apex/TOSearchSubscriptionController.getAccountList" {
  export default function getAccountList(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.fetchUserListForSavedSearch" {
  export default function fetchUserListForSavedSearch(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.getFormTypeList" {
  export default function getFormTypeList(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.getFormTypeFieldList" {
  export default function getFormTypeFieldList(param: {formType: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.getDeviceList" {
  export default function getDeviceList(param: {accountIds: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.getFieldInformationList" {
  export default function getFieldInformationList(param: {fieldList: any, formType: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.fetchObjectTypeInformation" {
  export default function fetchObjectTypeInformation(param: {formType: any, searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.searchResults" {
  export default function searchResults(param: {formType: any, createdDateValue: any, lastModifiedDateValue: any, fieldList: any, fromCreatedDate: any, toCreatedDate: any, fromLastModifiedDate: any, toLastModifiedDate: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.fetchSavedSearchResults" {
  export default function fetchSavedSearchResults(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.fetchSavedSearchCriteriaDetails" {
  export default function fetchSavedSearchCriteriaDetails(param: {searchKey: any, isEdit: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.saveSearchCriteria" {
  export default function saveSearchCriteria(param: {searchKey: any, searchName: any, formType: any, searchCriteriaRecords: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.saveSubscriberDetails" {
  export default function saveSubscriberDetails(param: {searchKey: any, subscriberDetail: any, userList: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.deleteSavedSearch" {
  export default function deleteSavedSearch(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.unsubscribeUser" {
  export default function unsubscribeUser(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.unsubscribeAllUser" {
  export default function unsubscribeAllUser(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.fetchColumnNamesViewResults" {
  export default function fetchColumnNamesViewResults(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.fetchViewResults" {
  export default function fetchViewResults(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.fetchMySubscribedFormDetails" {
  export default function fetchMySubscribedFormDetails(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.fetchAllMyFormDetails" {
  export default function fetchAllMyFormDetails(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.fetchAllMyFormColumnLabels" {
  export default function fetchAllMyFormColumnLabels(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.saveAutoSubscribedInforForUser" {
  export default function saveAutoSubscribedInforForUser(param: {isAutoSubscribed: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.getAutoSubscribedDetails" {
  export default function getAutoSubscribedDetails(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.unsubscribeFormForUser" {
  export default function unsubscribeFormForUser(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.getCustomSettingLables" {
  export default function getCustomSettingLables(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionController.getObjectSettingLables" {
  export default function getObjectSettingLables(): Promise<any>;
}
