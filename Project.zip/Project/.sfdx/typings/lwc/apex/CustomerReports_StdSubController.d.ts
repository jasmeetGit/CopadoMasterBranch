declare module "@salesforce/apex/CustomerReports_StdSubController.subscribedFolder" {
  export default function subscribedFolder(param: {reportFolder: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.getRelatedShipAddress" {
  export default function getRelatedShipAddress(param: {reporttype: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.getExistingAccShortNamesFromSubs" {
  export default function getExistingAccShortNamesFromSubs(param: {reporttype: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.getExistingSingleFileIds" {
  export default function getExistingSingleFileIds(param: {reporttype: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.getAccShortNames" {
  export default function getAccShortNames(): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.getsingleFileAcc" {
  export default function getsingleFileAcc(param: {singleId: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.getsingleFileEditAcc" {
  export default function getsingleFileEditAcc(param: {uniqueId: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.getCustEmail" {
  export default function getCustEmail(): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.getFileId" {
  export default function getFileId(param: {singleSubFileId: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.getfilename" {
  export default function getfilename(param: {singleSubUniqueId: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_StdSubController.upsertSubscription" {
  export default function upsertSubscription(param: {subscription: any}): Promise<any>;
}
