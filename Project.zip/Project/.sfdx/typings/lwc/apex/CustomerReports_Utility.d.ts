declare module "@salesforce/apex/CustomerReports_Utility.getSubcriptionList" {
  export default function getSubcriptionList(): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_Utility.getSubDetails" {
  export default function getSubDetails(param: {reporttype: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_Utility.getExistSubDetails" {
  export default function getExistSubDetails(param: {ids: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_Utility.UnsubscribeReports" {
  export default function UnsubscribeReports(param: {ids: any}): Promise<any>;
}
declare module "@salesforce/apex/CustomerReports_Utility.isCustomer" {
  export default function isCustomer(): Promise<any>;
}
