declare module "@salesforce/apex/FileUploadController.saveChunk" {
  export default function saveChunk(param: {parentId: any, fileName: any, base64Data: any, contentType: any, fileId: any, fileType: any}): Promise<any>;
}
