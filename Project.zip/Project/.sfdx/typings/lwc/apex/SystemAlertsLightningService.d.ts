declare module "@salesforce/apex/SystemAlertsLightningService.executeQuery" {
  export default function executeQuery(param: {soqlString: any}): Promise<any>;
}
declare module "@salesforce/apex/SystemAlertsLightningService.saveSObject" {
  export default function saveSObject(param: {record: any}): Promise<any>;
}
declare module "@salesforce/apex/SystemAlertsLightningService.getSystemAlerts" {
  export default function getSystemAlerts(param: {userId: any, origin: any, sideList: any, sideMenu: any}): Promise<any>;
}
declare module "@salesforce/apex/SystemAlertsLightningService.systemAlertsEmail" {
  export default function systemAlertsEmail(param: {systemAlertsId: any, feedback: any}): Promise<any>;
}
declare module "@salesforce/apex/SystemAlertsLightningService.getLoginType" {
  export default function getLoginType(): Promise<any>;
}
