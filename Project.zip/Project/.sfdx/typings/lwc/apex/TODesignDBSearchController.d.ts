declare module "@salesforce/apex/TODesignDBSearchController.getPicklistValue" {
  export default function getPicklistValue(): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBSearchController.getAllLabelAPIMap" {
  export default function getAllLabelAPIMap(): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBSearchController.selectedColAPIList" {
  export default function selectedColAPIList(param: {allFieldLabelAPIMap: any, selectedColumns: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBSearchController.getConditionalString" {
  export default function getConditionalString(param: {filterString: any, colList: any, selectedColumns: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBSearchController.getAllRecords" {
  export default function getAllRecords(param: {filterString: any, colList: any, selectedColumns: any, downloadcsv: any}): Promise<any>;
}
