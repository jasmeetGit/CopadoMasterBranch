declare module "@salesforce/apex/TOFTRFDeviceListController.getDeviceList" {
  export default function getDeviceList(): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFDeviceListController.createFormAndNavigate" {
  export default function createFormAndNavigate(param: {deviceId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFDeviceListController.updateFTRFIDOnDeviceObj" {
  export default function updateFTRFIDOnDeviceObj(param: {ftrfId: any}): Promise<any>;
}
