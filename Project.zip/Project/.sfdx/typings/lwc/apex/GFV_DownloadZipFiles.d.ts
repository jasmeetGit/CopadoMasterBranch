declare module "@salesforce/apex/GFV_DownloadZipFiles.getContentDistributionURL" {
  export default function getContentDistributionURL(param: {selectedFileId: any}): Promise<any>;
}
declare module "@salesforce/apex/GFV_DownloadZipFiles.downloadFilesFromExtSystem" {
  export default function downloadFilesFromExtSystem(param: {listOfCustomerReports: any, selectedFilesCount: any}): Promise<any>;
}
declare module "@salesforce/apex/GFV_DownloadZipFiles.insertAuditLog" {
  export default function insertAuditLog(param: {customerReportsList: any, errorMessage: any, fileDownloadOrigin: any}): Promise<any>;
}
declare module "@salesforce/apex/GFV_DownloadZipFiles.downloadFilesFromSFDC" {
  export default function downloadFilesFromSFDC(param: {selectedContentIdList: any}): Promise<any>;
}
