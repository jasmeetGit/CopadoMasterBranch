declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.getDevice" {
  export default function getDevice(param: {DeviceID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.getERPDevice" {
  export default function getERPDevice(param: {ERPDeviceID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.getupdateNWR" {
  export default function getupdateNWR(param: {NWRId: any, ERPDeviceID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.updateStageCDERPDevice" {
  export default function updateStageCDERPDevice(param: {ERPDeviceID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.RefreshStage" {
  export default function RefreshStage(): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.getTechReview" {
  export default function getTechReview(param: {ERPDeviceID: any, DeviceID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.getNonWaferRev" {
  export default function getNonWaferRev(param: {ERPDeviceID: any, DeviceID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.getNonWaferRevList" {
  export default function getNonWaferRevList(param: {ERPDeviceID: any, DeviceID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.createERPDevice" {
  export default function createERPDevice(param: {DeviceID: any, Erpname: any, DeliverableType: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.cloneERPDevice" {
  export default function cloneERPDevice(param: {ErpID: any, DeviceID: any, DeliverableType: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.ERPPrimary" {
  export default function ERPPrimary(param: {ErpID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.getAttachmentList" {
  export default function getAttachmentList(param: {NonWaferRevID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.getERPAttachmentList" {
  export default function getERPAttachmentList(param: {ERPDeviceID: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.getERPDeviceList" {
  export default function getERPDeviceList(param: {DeviceID: any, pageNumber: any, recordToDisply: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.searchMethod" {
  export default function searchMethod(param: {DeviceID: any, searchText: any, pageNumber: any, recordToDisply: any}): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.npadetails" {
  export default function npadetails(): Promise<any>;
}
declare module "@salesforce/apex/Lightning_DeviceOptionStageCntrl.prtsdetails" {
  export default function prtsdetails(): Promise<any>;
}
