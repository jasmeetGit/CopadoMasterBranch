declare module "@salesforce/apex/ExpConWaiverService.sendNotification" {
  export default function sendNotification(param: {devId: any, userEmail: any, userProfile: any}): Promise<any>;
}
