declare module "@salesforce/apex/TODWCTaskMessageConfig.getTaskMessage" {
  export default function getTaskMessage(param: {ftrfRecordId: any, loginUser: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCTaskMessageConfig.getUniqueFabs" {
  export default function getUniqueFabs(param: {formType: any, page: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCTaskMessageConfig.getUserList" {
  export default function getUserList(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCTaskMessageConfig.getUserConfigDetails" {
  export default function getUserConfigDetails(): Promise<any>;
}
declare module "@salesforce/apex/TODWCTaskMessageConfig.deleteUserConfigRecord" {
  export default function deleteUserConfigRecord(param: {userName: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCTaskMessageConfig.addUserConfigRecord" {
  export default function addUserConfigRecord(param: {userName: any, fabreader: any, fabrevert: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCTaskMessageConfig.updateUserConfigRecord" {
  export default function updateUserConfigRecord(param: {records: any, deleteRecords: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCTaskMessageConfig.checkRevertAccess" {
  export default function checkRevertAccess(param: {tapeoutFormId: any}): Promise<any>;
}
