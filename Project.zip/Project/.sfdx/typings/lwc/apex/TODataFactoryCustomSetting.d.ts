declare module "@salesforce/apex/TODataFactoryCustomSetting.getCustomSettingLables" {
  export default function getCustomSettingLables(param: {name: any}): Promise<any>;
}
