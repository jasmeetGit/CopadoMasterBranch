declare module "@salesforce/apex/TOViewAuditHistory.getRecords" {
  export default function getRecords(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOViewAuditHistory.getRelatedRecords" {
  export default function getRelatedRecords(param: {recordId: any, relatedObj: any, sObjApiName: any, formName: any}): Promise<any>;
}
declare module "@salesforce/apex/TOViewAuditHistory.getArchivedFiles" {
  export default function getArchivedFiles(param: {parentId: any}): Promise<any>;
}
