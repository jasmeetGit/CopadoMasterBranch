declare module "@salesforce/apex/RiskStartSystemHelper.processApprovalNew" {
  export default function processApprovalNew(param: {riskStartSystemId: any}): Promise<any>;
}
