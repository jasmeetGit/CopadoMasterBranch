declare module "@salesforce/apex/TODesignDBController.__sfdc_accountList" {
  export default function __sfdc_accountList(param: {value: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_accountList" {
  export default function __sfdc_accountList(): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_accounts" {
  export default function __sfdc_accounts(param: {value: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_accounts" {
  export default function __sfdc_accounts(): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_fileInfoList" {
  export default function __sfdc_fileInfoList(param: {value: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_fileInfoList" {
  export default function __sfdc_fileInfoList(): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_fileDatabaseList" {
  export default function __sfdc_fileDatabaseList(param: {value: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_fileDatabaseList" {
  export default function __sfdc_fileDatabaseList(): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_adminProfileList" {
  export default function __sfdc_adminProfileList(param: {value: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_adminProfileList" {
  export default function __sfdc_adminProfileList(): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_deviceInfo" {
  export default function __sfdc_deviceInfo(param: {value: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.__sfdc_deviceInfo" {
  export default function __sfdc_deviceInfo(): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.getDefaultAccounts" {
  export default function getDefaultAccounts(): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.getFileInfoDetails" {
  export default function getFileInfoDetails(param: {accountId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.getDatabaseCellDetails" {
  export default function getDatabaseCellDetails(param: {fileInfoId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.getDeviceDetails" {
  export default function getDeviceDetails(param: {deviceName: any}): Promise<any>;
}
declare module "@salesforce/apex/TODesignDBController.getmydomain" {
  export default function getmydomain(): Promise<any>;
}
