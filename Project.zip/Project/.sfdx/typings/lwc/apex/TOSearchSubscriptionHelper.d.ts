declare module "@salesforce/apex/TOSearchSubscriptionHelper.getFormTypeList" {
  export default function getFormTypeList(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.getFormTypeFieldList" {
  export default function getFormTypeFieldList(param: {formType: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.getUserListForExternalUser" {
  export default function getUserListForExternalUser(param: {acctList: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.getSavedSearchAccountList" {
  export default function getSavedSearchAccountList(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.getFieldInformationList" {
  export default function getFieldInformationList(param: {fieldList: any, formType: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.fetchObjectTypeInformation" {
  export default function fetchObjectTypeInformation(param: {formType: any, searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.searchResults" {
  export default function searchResults(param: {formType: any, createdDateValue: any, lastModifiedDateValue: any, fieldList: any, fromCreatedDate: any, toCreatedDate: any, fromLastModifiedDate: any, toLastModifiedDate: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.fetchSavedSearchResults" {
  export default function fetchSavedSearchResults(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.fetchSavedSearchCriteriaDetails" {
  export default function fetchSavedSearchCriteriaDetails(param: {searchKey: any, isEdit: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.saveSearchCriteria" {
  export default function saveSearchCriteria(param: {searchKey: any, searchName: any, formType: any, searchCriteriaRecords: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.saveSubscriberDetails" {
  export default function saveSubscriberDetails(param: {searchKey: any, subscriberDetail: any, userList: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.deleteSavedSearch" {
  export default function deleteSavedSearch(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.unsubscribeUser" {
  export default function unsubscribeUser(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.unsubscribeAllUser" {
  export default function unsubscribeAllUser(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.fetchColumnNamesViewResults" {
  export default function fetchColumnNamesViewResults(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.fetchViewResults" {
  export default function fetchViewResults(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.saveAutoSubscribedInforForUser" {
  export default function saveAutoSubscribedInforForUser(param: {isAutoSubscribed: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.getAutoSubscribedDetails" {
  export default function getAutoSubscribedDetails(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.unsubscribeFormForUser" {
  export default function unsubscribeFormForUser(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.fetchMySubscribedFormDetails" {
  export default function fetchMySubscribedFormDetails(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.fetchAllMyFormColumnLabels" {
  export default function fetchAllMyFormColumnLabels(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.fetchAllMyFormDetails" {
  export default function fetchAllMyFormDetails(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.getCustomSettingLables" {
  export default function getCustomSettingLables(): Promise<any>;
}
declare module "@salesforce/apex/TOSearchSubscriptionHelper.getObjectSettingLables" {
  export default function getObjectSettingLables(): Promise<any>;
}
