declare module "@salesforce/apex/LightningCDSWrapper.oppStage" {
  export default function oppStage(param: {oppid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getRecTypeId" {
  export default function getRecTypeId(param: {recordTypeLabel: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getLightningCDSWrapper" {
  export default function getLightningCDSWrapper(param: {devid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getOptionStage" {
  export default function getOptionStage(param: {devid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getCDRS" {
  export default function getCDRS(param: {devid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.fetchUser" {
  export default function fetchUser(): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getPicklistvalues" {
  export default function getPicklistvalues(param: {objectName: any, field_apiname: any, nullRequired: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getCDSValues" {
  export default function getCDSValues(): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getOppProgram" {
  export default function getOppProgram(param: {devid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getRecordType" {
  export default function getRecordType(param: {sobjecttype: any, name: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getDeviceCreatable" {
  export default function getDeviceCreatable(): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getOppProgram1" {
  export default function getOppProgram1(param: {oppid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getaccRecordType" {
  export default function getaccRecordType(param: {oppid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getdevicenew" {
  export default function getdevicenew(param: {oppid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getdevicenew1" {
  export default function getdevicenew1(param: {devid: any, objName: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getListSettings" {
  export default function getListSettings(): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getListSettings1" {
  export default function getListSettings1(): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getListSettings2" {
  export default function getListSettings2(): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.getbug" {
  export default function getbug(param: {bugid: any, userid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.createRecord" {
  export default function createRecord(param: {staff: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.updateRecord" {
  export default function updateRecord(param: {staff: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.closebug" {
  export default function closebug(param: {bugid: any, userid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.closebug1" {
  export default function closebug1(param: {bugid: any, userid: any}): Promise<any>;
}
declare module "@salesforce/apex/LightningCDSWrapper.closebug2" {
  export default function closebug2(param: {bugid: any, userid: any}): Promise<any>;
}
