declare module "@salesforce/apex/FullCalendarController.getEvents" {
  export default function getEvents(param: {visitType: any, calLoc: any}): Promise<any>;
}
