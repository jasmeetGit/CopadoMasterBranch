declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getConfigTableMap" {
  export default function getConfigTableMap(): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getConfigLogicalData" {
  export default function getConfigLogicalData(param: {tapeoutRoute: any, fab: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getDDRConfigLogicalData" {
  export default function getDDRConfigLogicalData(param: {page: any, formType: any, configName: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFieldLabelsMessages" {
  export default function getFieldLabelsMessages(): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFieldLabelsMessagesService" {
  export default function getFieldLabelsMessagesService(param: {formType: any, page: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFieldLabelsMessagesServiceNew" {
  export default function getFieldLabelsMessagesServiceNew(param: {formType: any, page: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getProcessInfo" {
  export default function getProcessInfo(param: {processId: any, designManual: any, addendumDesingManual: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getCSVFileTemplateUrl" {
  export default function getCSVFileTemplateUrl(): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getKERFConfigData" {
  export default function getKERFConfigData(param: {technology: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFloorPlanPartNumbers" {
  export default function getFloorPlanPartNumbers(param: {accShortName: any, foundryTechnology: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFloorPlanNumMaskSetTitles" {
  export default function getFloorPlanNumMaskSetTitles(param: {accShortName: any, foundryTechnology: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getTapeoutServiceForms" {
  export default function getTapeoutServiceForms(param: {prototypeformId: any, listOfFormStatuses: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getContentVersion" {
  export default function getContentVersion(param: {docId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getContentVersionList" {
  export default function getContentVersionList(param: {docIds: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFiles" {
  export default function getFiles(param: {cIDds: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFileBaseURL" {
  export default function getFileBaseURL(): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getTapeoutServiceFormRecord" {
  export default function getTapeoutServiceFormRecord(param: {tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.insertPrimeDieChips" {
  export default function insertPrimeDieChips(param: {formId: any, primeDieList: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFRTRFTapeoutServiceFromData" {
  export default function getFRTRFTapeoutServiceFromData(param: {toServiceFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.createDRCDeckRules" {
  export default function createDRCDeckRules(param: {lstOfRulesObj: any, tapeoutformId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getListOfDRCDeckRules" {
  export default function getListOfDRCDeckRules(param: {tapeoutServicesFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getChipDetails" {
  export default function getChipDetails(param: {ftrfId: any, tabName: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.upsertDDRBumpLayerInformation" {
  export default function upsertDDRBumpLayerInformation(param: {deletedDDRchipIds: any, deletedBumpChipIds: any, tsfId: any, ddrChipList: any, bumpChipList: any, destinationForBump: any, tapeoutType: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getDdrChips" {
  export default function getDdrChips(param: {tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getBumpChips" {
  export default function getBumpChips(param: {tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getDesignDBData" {
  export default function getDesignDBData(param: {ftrfServId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getDesignDBdataStatus" {
  export default function getDesignDBdataStatus(param: {selectDBIds: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFTRFDatabaseInfo" {
  export default function getFTRFDatabaseInfo(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getToFTRFPrototypeRetrofitPrimeDie" {
  export default function getToFTRFPrototypeRetrofitPrimeDie(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getStepPlanTapeoutServiceForms" {
  export default function getStepPlanTapeoutServiceForms(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getSubmittedPrimeDieNames" {
  export default function getSubmittedPrimeDieNames(param: {parentFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getSubmittedStepPlanPrimeDieNames" {
  export default function getSubmittedStepPlanPrimeDieNames(param: {parentFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getSubmittedFTRFChipData" {
  export default function getSubmittedFTRFChipData(param: {accountId: any, formId: any, eccnTech: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getDRCRunsetData" {
  export default function getDRCRunsetData(param: {processId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getDRCRunsetInfoData" {
  export default function getDRCRunsetInfoData(param: {toServiceFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getDRCRunsetForADM" {
  export default function getDRCRunsetForADM(param: {designManualNumber: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getEBeamShrinkVal" {
  export default function getEBeamShrinkVal(param: {itemNumber: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getProcessTech" {
  export default function getProcessTech(param: {ptNum: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.createUpdtDBInfo" {
  export default function createUpdtDBInfo(param: {primeDieList: any, scribeLineDrpinList: any, deletePrimeDieIds: any, deleteScrlineDrpinIds: any, frtfServiceId: any, operation: any, stepPlanChk: any, primeReqChk: any, DRCReqChk: any, parentFormType: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.emailNotification" {
  export default function emailNotification(param: {tsfId: any, templateName: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.cloneForm" {
  export default function cloneForm(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getPastDeckRules" {
  export default function getPastDeckRules(param: {ftrfFormId: any, lstOfStatus: any, rulesToReviewValue: any, formType: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getChipsValidation" {
  export default function getChipsValidation(param: {maskSetTitle: any, chipNames: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFoundryInfo" {
  export default function getFoundryInfo(param: {toServiceFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getTopMostParentFEOLBEOLSplitValue" {
  export default function getTopMostParentFEOLBEOLSplitValue(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.updateProtoForm" {
  export default function updateProtoForm(param: {protoFormId: any, eccnTechPF: any, devExpConColorPF: any, eccnTechTS: any, devExpConColorTS: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getPickListMap" {
  export default function getPickListMap(param: {objectName: any, fieldName: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getActiveStepPlanForParent" {
  export default function getActiveStepPlanForParent(param: {tsfParentFormId: any, tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getActiveStepPlanUnderParentForm" {
  export default function getActiveStepPlanUnderParentForm(param: {tsfParentFormId: any, tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getStepPlanTSFsForPrototype" {
  export default function getStepPlanTSFsForPrototype(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getParentStepPlanTSF" {
  export default function getParentStepPlanTSF(param: {tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getFEOLBEOLTapeoutServiceForms" {
  export default function getFEOLBEOLTapeoutServiceForms(param: {parentFormId: any, lstOfStatus: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getRelatedActiveStepplanChips" {
  export default function getRelatedActiveStepplanChips(param: {parentFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getDBInfoValidation" {
  export default function getDBInfoValidation(param: {parentFormId: any, parentFormType: any, tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getActiveStepPlanFormStatusList" {
  export default function getActiveStepPlanFormStatusList(): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getCustomSettingLabels" {
  export default function getCustomSettingLabels(param: {csName: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getAccessSetupDetails" {
  export default function getAccessSetupDetails(): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.isThereActivePrimeRequest" {
  export default function isThereActivePrimeRequest(param: {parentFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFTapeoutServiceFormController.getStepPlanReviewAccess" {
  export default function getStepPlanReviewAccess(): Promise<any>;
}
