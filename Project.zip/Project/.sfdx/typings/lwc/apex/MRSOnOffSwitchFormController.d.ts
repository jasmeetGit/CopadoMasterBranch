declare module "@salesforce/apex/MRSOnOffSwitchFormController.getSettings" {
  export default function getSettings(): Promise<any>;
}
declare module "@salesforce/apex/MRSOnOffSwitchFormController.saveSetting" {
  export default function saveSetting(param: {settingJson: any}): Promise<any>;
}
