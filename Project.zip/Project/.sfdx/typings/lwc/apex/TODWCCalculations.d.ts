declare module "@salesforce/apex/TODWCCalculations.finalRevewAndReviewStausCalcOnRuleList" {
  export default function finalRevewAndReviewStausCalcOnRuleList(param: {rulesList: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculations.finalStausCalcOnRuleList" {
  export default function finalStausCalcOnRuleList(param: {rulesList: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculations.PrimeDieReviewStatusCalculationTRG" {
  export default function PrimeDieReviewStatusCalculationTRG(param: {dwcRecordId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculations.AggregatedReviewStatusCalculation" {
  export default function AggregatedReviewStatusCalculation(param: {dwcRecordIds: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculations.getUserType" {
  export default function getUserType(): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculations.getRevertPermission" {
  export default function getRevertPermission(param: {tsfId: any}): Promise<any>;
}
