declare module "@salesforce/apex/TakeOwnershipController.updatecase" {
  export default function updatecase(param: {newId: any, caseId: any}): Promise<any>;
}
