declare module "@salesforce/apex/TOConfigDataUtil.getLoggedInUserInfo" {
  export default function getLoggedInUserInfo(): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getUserGroup" {
  export default function getUserGroup(): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getAssignedPermissionSet" {
  export default function getAssignedPermissionSet(): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getDRCConfigurationTable" {
  export default function getDRCConfigurationTable(param: {designManual: any, addendumDesignManual: any, readFromProcessId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.checkDesignEnablementSpecRec" {
  export default function checkDesignEnablementSpecRec(param: {desingOrAddDesignManual: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getCSVFileTemplateUrl" {
  export default function getCSVFileTemplateUrl(): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getDownloadableUrl" {
  export default function getDownloadableUrl(param: {fileNameOrId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.shareUploadedFile" {
  export default function shareUploadedFile(param: {recordId: any, fileIds: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getProcessData" {
  export default function getProcessData(param: {processID: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.cloneForm" {
  export default function cloneForm(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getCaseNumbers" {
  export default function getCaseNumbers(param: {accShortName: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.deleteDRCDeckRules" {
  export default function deleteDRCDeckRules(param: {lstOfDeckRuleIds: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getStepPlanReviewData" {
  export default function getStepPlanReviewData(param: {serviceFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.updateStepPlanReviewData" {
  export default function updateStepPlanReviewData(param: {dataToUpdate: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getStepPlanReviewId" {
  export default function getStepPlanReviewId(param: {serviceFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getPTNumberAndTechType" {
  export default function getPTNumberAndTechType(param: {toFTRFformId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getDRCConfigTableData" {
  export default function getDRCConfigTableData(param: {desingOrAdManual: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getSystemAttachment" {
  export default function getSystemAttachment(param: {toServiceFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getSystemAttachmentTest" {
  export default function getSystemAttachmentTest(param: {toServiceFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getDeviceDetails" {
  export default function getDeviceDetails(param: {deviceId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOConfigDataUtil.getFileFromContDist" {
  export default function getFileFromContDist(param: {cIDds: any, recordId: any}): Promise<any>;
}
