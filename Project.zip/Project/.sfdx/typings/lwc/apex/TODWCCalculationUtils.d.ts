declare module "@salesforce/apex/TODWCCalculationUtils.getRuleOptionsConfig" {
  export default function getRuleOptionsConfig(): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculationUtils.getRuleOptionsConfigRevert" {
  export default function getRuleOptionsConfigRevert(): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculationUtils.getRuleLegendConfigMap" {
  export default function getRuleLegendConfigMap(): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculationUtils.getRuleStatusCalculationConfig" {
  export default function getRuleStatusCalculationConfig(): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculationUtils.getTaskMessageConfig" {
  export default function getTaskMessageConfig(): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculationUtils.getConfigList" {
  export default function getConfigList(): Promise<any>;
}
declare module "@salesforce/apex/TODWCCalculationUtils.getUserDetails" {
  export default function getUserDetails(): Promise<any>;
}
