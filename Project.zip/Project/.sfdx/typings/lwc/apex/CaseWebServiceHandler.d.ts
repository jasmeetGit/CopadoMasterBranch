declare module "@salesforce/apex/CaseWebServiceHandler.getGroupMember" {
  export default function getGroupMember(): Promise<any>;
}
declare module "@salesforce/apex/CaseWebServiceHandler.assignL2Button" {
  export default function assignL2Button(param: {caseId: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseWebServiceHandler.check_Region" {
  export default function check_Region(): Promise<any>;
}
declare module "@salesforce/apex/CaseWebServiceHandler.check_ATP" {
  export default function check_ATP(): Promise<any>;
}
declare module "@salesforce/apex/CaseWebServiceHandler.isNotBlank" {
  export default function isNotBlank(param: {val: any}): Promise<any>;
}
declare module "@salesforce/apex/CaseWebServiceHandler.getCase" {
  export default function getCase(param: {Id: any}): Promise<any>;
}
