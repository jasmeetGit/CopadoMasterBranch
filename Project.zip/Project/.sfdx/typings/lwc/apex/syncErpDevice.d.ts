declare module "@salesforce/apex/syncErpDevice.callSyncErpDevice" {
  export default function callSyncErpDevice(param: {ERP_Device_ID: any}): Promise<any>;
}
declare module "@salesforce/apex/syncErpDevice.getErpDevice" {
  export default function getErpDevice(param: {deviceId: any}): Promise<any>;
}
