declare module "@salesforce/apex/FieldSetLexFormController.getForm" {
  export default function getForm(param: {recordId: any, objectName: any, fieldSetName: any}): Promise<any>;
}
declare module "@salesforce/apex/FieldSetLexFormController.hasEditAccessOnSalesOps" {
  export default function hasEditAccessOnSalesOps(): Promise<any>;
}
declare module "@salesforce/apex/FieldSetLexFormController.hasEditAccessOnStakeholder" {
  export default function hasEditAccessOnStakeholder(): Promise<any>;
}
