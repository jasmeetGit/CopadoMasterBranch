declare module "@salesforce/apex/IPDeclarationMatching.setToNextMatchingProcess" {
  export default function setToNextMatchingProcess(param: {recordID: any}): Promise<any>;
}
declare module "@salesforce/apex/IPDeclarationMatching.overrideIP" {
  export default function overrideIP(param: {IPDeclarationFormIDs: any}): Promise<any>;
}
declare module "@salesforce/apex/IPDeclarationMatching.validateIPForm" {
  export default function validateIPForm(param: {formId: any}): Promise<any>;
}
