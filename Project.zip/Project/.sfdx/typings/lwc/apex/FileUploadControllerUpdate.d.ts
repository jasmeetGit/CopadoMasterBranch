declare module "@salesforce/apex/FileUploadControllerUpdate.saveChunk" {
  export default function saveChunk(param: {parentId: any, fileName: any, base64Data: any, contentType: any, fileId: any}): Promise<any>;
}
declare module "@salesforce/apex/FileUploadControllerUpdate.ContentVersions" {
  export default function ContentVersions(param: {parentId: any}): Promise<any>;
}
declare module "@salesforce/apex/FileUploadControllerUpdate.deleteContentVersions" {
  export default function deleteContentVersions(param: {cvId: any}): Promise<any>;
}
