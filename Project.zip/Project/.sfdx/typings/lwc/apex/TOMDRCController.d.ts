declare module "@salesforce/apex/TOMDRCController.getMDRCRecords" {
  export default function getMDRCRecords(param: {maskSetTitle: any, customerShortName: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMDRCController.getCustomerList" {
  export default function getCustomerList(param: {maskSetTitle: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMDRCController.getMasksetTitleList" {
  export default function getMasksetTitleList(param: {searchKey: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMDRCController.getMDRCMaskSetTitleRecords" {
  export default function getMDRCMaskSetTitleRecords(): Promise<any>;
}
declare module "@salesforce/apex/TOMDRCController.updateMDRCLayerAccount" {
  export default function updateMDRCLayerAccount(param: {mdrcLayerAccountRecords: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMDRCController.checkMDRCAccess" {
  export default function checkMDRCAccess(): Promise<any>;
}
declare module "@salesforce/apex/TOMDRCController.getFieldLabelsMessagesPrototype" {
  export default function getFieldLabelsMessagesPrototype(param: {formType: any, page: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMDRCController.getUserType" {
  export default function getUserType(): Promise<any>;
}
