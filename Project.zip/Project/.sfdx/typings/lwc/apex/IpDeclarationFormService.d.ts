declare module "@salesforce/apex/IpDeclarationFormService.reOpen" {
  export default function reOpen(param: {ipDecFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/IpDeclarationFormService.submitForApproval" {
  export default function submitForApproval(param: {ipDecFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/IpDeclarationFormService.validateReassign" {
  export default function validateReassign(param: {formId: any}): Promise<any>;
}
