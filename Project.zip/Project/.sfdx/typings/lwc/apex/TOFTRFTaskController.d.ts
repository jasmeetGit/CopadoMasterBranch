declare module "@salesforce/apex/TOFTRFTaskController.taskDetails" {
  export default function taskDetails(param: {taskId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFTaskController.updateForm" {
  export default function updateForm(param: {taskId: any, formId: any, option: any, justifytext: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFTaskController.taskcontent" {
  export default function taskcontent(param: {taskId: any}): Promise<any>;
}
