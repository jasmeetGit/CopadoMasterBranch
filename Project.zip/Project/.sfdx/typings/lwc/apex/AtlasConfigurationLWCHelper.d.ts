declare module "@salesforce/apex/AtlasConfigurationLWCHelper.fetchConfiguredDevices" {
  export default function fetchConfiguredDevices(param: {configId: any}): Promise<any>;
}
declare module "@salesforce/apex/AtlasConfigurationLWCHelper.fetchConfiguredIPs" {
  export default function fetchConfiguredIPs(param: {configId: any}): Promise<any>;
}
declare module "@salesforce/apex/AtlasConfigurationLWCHelper.fetchConfiguredPackagingSelections" {
  export default function fetchConfiguredPackagingSelections(param: {configId: any}): Promise<any>;
}
