declare module "@salesforce/apex/TOFTRFProtoFormController.getProcessData" {
  export default function getProcessData(param: {processId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getBiasTableDetails" {
  export default function getBiasTableDetails(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getBiasTable" {
  export default function getBiasTable(param: {biasTableNumber: any, biasTableVersion: any, metalLayer: any, geometry: any, maskLayer: any, processId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getMaskLayers" {
  export default function getMaskLayers(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getConfigTableMap" {
  export default function getConfigTableMap(): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getFieldLabelsMessagesPrototype" {
  export default function getFieldLabelsMessagesPrototype(param: {formType: any, page: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getDesignManualValues" {
  export default function getDesignManualValues(param: {deviceId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getDMFromDES" {
  export default function getDMFromDES(param: {deviceId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getDeviceObj" {
  export default function getDeviceObj(param: {deviceId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.updateRetrofitPrimeDies" {
  export default function updateRetrofitPrimeDies(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.setSubmitter" {
  export default function setSubmitter(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getFormType" {
  export default function getFormType(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.returnForm" {
  export default function returnForm(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.emailNotificationOnSubmitRetrofit" {
  export default function emailNotificationOnSubmitRetrofit(param: {formId: any, primaryContact: any, awailableContacts: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.emailNotificationOnSubmit" {
  export default function emailNotificationOnSubmit(param: {formId: any, primaryContact: any, awailableContacts: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.updateDeselectedLayers" {
  export default function updateDeselectedLayers(param: {lsfOfLayerIds: any, formId: any, deselMessage: any, deselReason: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.emailNotificationOnDeselectLayer" {
  export default function emailNotificationOnDeselectLayer(param: {formId: any, deselMessage: any, deselReason: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getProtypeRecord" {
  export default function getProtypeRecord(param: {ftrfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.upsertLayerInformation" {
  export default function upsertLayerInformation(param: {psfId: any, formName: any, maskLayer: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.updateContacts" {
  export default function updateContacts(param: {ftrfId: any, primaryContact: any, pUser: any, awailableContacts: any, primaryContactChanged: any, awailableContactChanged: any, updateFromPopup: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.updateCustomerContacts" {
  export default function updateCustomerContacts(param: {ftrfId: any, primaryContact: any, pUser: any, awailableContacts: any, primaryContactChanged: any, awailableContactChanged: any, isadditionalContact: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getLoggedinUserInfo" {
  export default function getLoggedinUserInfo(param: {userId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOFTRFProtoFormController.getContacts" {
  export default function getContacts(param: {ftrfId: any}): Promise<any>;
}
