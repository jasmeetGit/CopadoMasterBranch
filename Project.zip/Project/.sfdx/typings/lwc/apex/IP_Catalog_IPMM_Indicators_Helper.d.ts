declare module "@salesforce/apex/IP_Catalog_IPMM_Indicators_Helper.getIpmmIndicators" {
  export default function getIpmmIndicators(param: {startsWith: any, indicatorTypeName: any}): Promise<any>;
}
