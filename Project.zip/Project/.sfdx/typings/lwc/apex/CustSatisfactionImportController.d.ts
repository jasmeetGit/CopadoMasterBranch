declare module "@salesforce/apex/CustSatisfactionImportController.insertData" {
  export default function insertData(param: {strfromle: any, recordId: any, sObjectType: any, selectType: any}): Promise<any>;
}
