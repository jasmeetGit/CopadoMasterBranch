declare module "@salesforce/apex/GFV_DownloadFilesUtility.fetchUserInformation" {
  export default function fetchUserInformation(): Promise<any>;
}
