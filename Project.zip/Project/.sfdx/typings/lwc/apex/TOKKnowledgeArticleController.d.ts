declare module "@salesforce/apex/TOKKnowledgeArticleController.getTopicName" {
  export default function getTopicName(param: {recId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOKKnowledgeArticleController.checkIsUserRegisteredForSolution" {
  export default function checkIsUserRegisteredForSolution(param: {recId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOKKnowledgeArticleController.registerSolution" {
  export default function registerSolution(param: {topicName: any}): Promise<any>;
}
