declare module "@salesforce/apex/ToFTRFFormHierarchyController.getFormDetails" {
  export default function getFormDetails(param: {FormId: any}): Promise<any>;
}
