declare module "@salesforce/apex/IPMatchingOverride.overrideVCID_IP" {
  export default function overrideVCID_IP(param: {recID: any, overrideType: any}): Promise<any>;
}
