declare module "@salesforce/apex/TODWCFormController.getRulelistAttachment" {
  export default function getRulelistAttachment(param: {ruleId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getDWCRecordId" {
  export default function getDWCRecordId(param: {tapeoutFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getDWCRecord" {
  export default function getDWCRecord(param: {tapeoutFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getCustomerName" {
  export default function getCustomerName(param: {tapeoutFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getRulesList" {
  export default function getRulesList(param: {tapeoutFromID: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getDwcServiceChipInfo" {
  export default function getDwcServiceChipInfo(param: {tapeoutFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getRulesListPDF" {
  export default function getRulesListPDF(param: {tapeoutFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getReviewStatus" {
  export default function getReviewStatus(): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.updateRulesList" {
  export default function updateRulesList(param: {dwcID: any, rulesList: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getDisclamierList" {
  export default function getDisclamierList(): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.updateDWCAfterRevert" {
  export default function updateDWCAfterRevert(param: {dwcRcdListAfterRevert: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.deleteRulelistAttachmentOnRevert" {
  export default function deleteRulelistAttachmentOnRevert(param: {rulesList: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.emailToBeSentfromRevert" {
  export default function emailToBeSentfromRevert(param: {dwcRecordList: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getDwcRecord" {
  export default function getDwcRecord(param: {dwcRecordID: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.collabratorSubmitValidation" {
  export default function collabratorSubmitValidation(param: {tapeoutFromID: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.collabratorSubmitHandler" {
  export default function collabratorSubmitHandler(param: {dwcRecordID: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.submitCollabratorCalculations" {
  export default function submitCollabratorCalculations(param: {dwcRecordID: any, rulesList: any, revertReasonCollab: any, collabStatusRevert: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.CollaboratorStatusCalculation" {
  export default function CollaboratorStatusCalculation(param: {dwcRecordList: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.taskPendingFAEActionOnFCD" {
  export default function taskPendingFAEActionOnFCD(param: {dwcRecordID: any, tempName: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.handlePrimeDieDeselection" {
  export default function handlePrimeDieDeselection(param: {PrimeDielist: any, tsfId: any, dwcId: any, isAfterLayerDeselctionReq: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCFormController.getFieldLabelsMessagesPrototype" {
  export default function getFieldLabelsMessagesPrototype(param: {formType: any, page: any}): Promise<any>;
}
