declare module "@salesforce/apex/iWIP_LightningGenericService.deleteReportSub" {
  export default function deleteReportSub(param: {record: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getSalesforceBaseUrl" {
  export default function getSalesforceBaseUrl(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getCurrentUser" {
  export default function getCurrentUser(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getUserProfile" {
  export default function getUserProfile(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.saveReportSubscription" {
  export default function saveReportSubscription(param: {record: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.refreshCustomReportSubscription" {
  export default function refreshCustomReportSubscription(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getWipReportGuideURL" {
  export default function getWipReportGuideURL(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getTrainingMaterial" {
  export default function getTrainingMaterial(param: {tabLabel: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getTrainingMaterialTabs" {
  export default function getTrainingMaterialTabs(param: {buttonName: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getReportDetails" {
  export default function getReportDetails(param: {reportId: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getSearchKeyword" {
  export default function getSearchKeyword(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.cloneStandardReport" {
  export default function cloneStandardReport(param: {reportId: any, reportName: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.deletePersonalReport" {
  export default function deletePersonalReport(param: {reportId: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getUserPreference" {
  export default function getUserPreference(param: {userid: any, userType: any, displaymodeval: any, ReportFilteractiveVal: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getSharedReport" {
  export default function getSharedReport(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getCustomerAccess" {
  export default function getCustomerAccess(param: {URL: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getUserPreferences" {
  export default function getUserPreferences(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getCustomReports" {
  export default function getCustomReports(param: {URL: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getTab" {
  export default function getTab(param: {URL: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getStandardReports" {
  export default function getStandardReports(param: {URL: any}): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getReportSubscriptions" {
  export default function getReportSubscriptions(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.fetchUser" {
  export default function fetchUser(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getRecentItems" {
  export default function getRecentItems(): Promise<any>;
}
declare module "@salesforce/apex/iWIP_LightningGenericService.getRecentReports" {
  export default function getRecentReports(): Promise<any>;
}
