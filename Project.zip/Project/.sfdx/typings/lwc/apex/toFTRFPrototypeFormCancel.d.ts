declare module "@salesforce/apex/toFTRFPrototypeFormCancel.getRecords" {
  export default function getRecords(param: {FTRFFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFPrototypeFormCancel.cancelProtoForm" {
  export default function cancelProtoForm(param: {ftrfForm: any, cancelAssociatedFormType: any, formType: any, device: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFPrototypeFormCancel.CheckIfPrimeRequest" {
  export default function CheckIfPrimeRequest(param: {FormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFPrototypeFormCancel.getMDRCRecordsByFTRFFormId" {
  export default function getMDRCRecordsByFTRFFormId(param: {FTRFFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/toFTRFPrototypeFormCancel.getMDRCRecordsByTSFId" {
  export default function getMDRCRecordsByTSFId(param: {ftrfId: any}): Promise<any>;
}
