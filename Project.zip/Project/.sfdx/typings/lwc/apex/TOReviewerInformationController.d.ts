declare module "@salesforce/apex/TOReviewerInformationController.getUserInfo" {
  export default function getUserInfo(): Promise<any>;
}
declare module "@salesforce/apex/TOReviewerInformationController.getFormData" {
  export default function getFormData(param: {tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOReviewerInformationController.getCreateContacts" {
  export default function getCreateContacts(param: {tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOReviewerInformationController.getUpdateContacts" {
  export default function getUpdateContacts(param: {tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOReviewerInformationController.updateContacts" {
  export default function updateContacts(param: {tsfId: any, contactsToInsert: any, contactsToDelete: any, foundryReviewerToInsert: any}): Promise<any>;
}
declare module "@salesforce/apex/TOReviewerInformationController.getStandardFoundryReviewers" {
  export default function getStandardFoundryReviewers(param: {tsfId: any, orderType: any}): Promise<any>;
}
declare module "@salesforce/apex/TOReviewerInformationController.emailNotificationOnReviewerUpdate" {
  export default function emailNotificationOnReviewerUpdate(param: {tsfId: any, modifiedMap: any}): Promise<any>;
}
declare module "@salesforce/apex/TOReviewerInformationController.validateWithMDRC" {
  export default function validateWithMDRC(param: {tsfId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOReviewerInformationController.validateWithMDRCAndLayerChip" {
  export default function validateWithMDRCAndLayerChip(param: {tsfId: any}): Promise<any>;
}
