declare module "@salesforce/apex/TOMSAllocation.readFTRFTOServiceForm" {
  export default function readFTRFTOServiceForm(param: {maskSetTitle: any, type: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAllocation.updateFTRFTOServiceForm" {
  export default function updateFTRFTOServiceForm(param: {formData: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAllocation.moveFTRFServiceForm" {
  export default function moveFTRFServiceForm(param: {formId: any}): Promise<any>;
}
