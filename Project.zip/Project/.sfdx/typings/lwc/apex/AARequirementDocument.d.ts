declare module "@salesforce/apex/AARequirementDocument.getWorkDetails" {
  export default function getWorkDetails(param: {workId: any}): Promise<any>;
}
declare module "@salesforce/apex/AARequirementDocument.getBuildDetails" {
  export default function getBuildDetails(param: {buildId: any}): Promise<any>;
}
declare module "@salesforce/apex/AARequirementDocument.getBuilds" {
  export default function getBuilds(): Promise<any>;
}
declare module "@salesforce/apex/AARequirementDocument.getDesign" {
  export default function getDesign(param: {designId: any}): Promise<any>;
}
declare module "@salesforce/apex/AARequirementDocument.approve" {
  export default function approve(param: {workId: any, field: any, value: any}): Promise<any>;
}
declare module "@salesforce/apex/AARequirementDocument.getUserType" {
  export default function getUserType(): Promise<any>;
}
