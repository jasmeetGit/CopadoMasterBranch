declare module "@salesforce/apex/LotApprovalProcessUtil.activeMLonLotinstr" {
  export default function activeMLonLotinstr(param: {lsrId: any}): Promise<any>;
}
