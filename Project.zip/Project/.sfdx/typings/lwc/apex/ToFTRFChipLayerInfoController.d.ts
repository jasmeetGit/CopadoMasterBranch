declare module "@salesforce/apex/ToFTRFChipLayerInfoController.getChipLayerInfo" {
  export default function getChipLayerInfo(param: {serviceFormId: any}): Promise<any>;
}
declare module "@salesforce/apex/ToFTRFChipLayerInfoController.updateChipLayerInfo" {
  export default function updateChipLayerInfo(param: {JSONResp: any, tsfId: any, deSelMsg: any, deSelReason: any}): Promise<any>;
}
declare module "@salesforce/apex/ToFTRFChipLayerInfoController.deselectChips" {
  export default function deselectChips(param: {setOfChipIds: any}): Promise<any>;
}
declare module "@salesforce/apex/ToFTRFChipLayerInfoController.getCurrentUserTypeOrGroupName" {
  export default function getCurrentUserTypeOrGroupName(): Promise<any>;
}
declare module "@salesforce/apex/ToFTRFChipLayerInfoController.getServiceRequest" {
  export default function getServiceRequest(param: {tsfFormId: any}): Promise<any>;
}
