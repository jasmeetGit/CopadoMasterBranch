declare module "@salesforce/apex/TOOneGFController.getUserInformation" {
  export default function getUserInformation(): Promise<any>;
}
declare module "@salesforce/apex/TOOneGFController.getAccessSetupDetails" {
  export default function getAccessSetupDetails(): Promise<any>;
}
declare module "@salesforce/apex/TOOneGFController.checkMDRCAccess" {
  export default function checkMDRCAccess(): Promise<any>;
}
declare module "@salesforce/apex/TOOneGFController.getMaskshopAccessSetupDetails" {
  export default function getMaskshopAccessSetupDetails(): Promise<any>;
}
declare module "@salesforce/apex/TOOneGFController.getdocumentIds" {
  export default function getdocumentIds(): Promise<any>;
}
