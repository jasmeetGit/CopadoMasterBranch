declare module "@salesforce/apex/ValidateAndSubmitTOR.validateAndSubmitTORRec" {
  export default function validateAndSubmitTORRec(param: {deviceId: any}): Promise<any>;
}
