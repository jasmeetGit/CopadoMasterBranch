declare module "@salesforce/apex/KnowledgeController.findArticles" {
  export default function findArticles(param: {topicId: any}): Promise<any>;
}
declare module "@salesforce/apex/KnowledgeController.fetchOrgUrl" {
  export default function fetchOrgUrl(): Promise<any>;
}
