declare module "@salesforce/apex/GFV_downloadSingleFile.getContentDistributionURL" {
  export default function getContentDistributionURL(param: {customerReport: any}): Promise<any>;
}
declare module "@salesforce/apex/GFV_downloadSingleFile.insertAuditLog" {
  export default function insertAuditLog(param: {customerReportsList: any, errorMessage: any, fileDownloadOrigin: any}): Promise<any>;
}
declare module "@salesforce/apex/GFV_downloadSingleFile.logFileDownloadFromEmail" {
  export default function logFileDownloadFromEmail(param: {responseStatus: any, zipFileName: any}): Promise<any>;
}
