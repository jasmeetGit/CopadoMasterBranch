declare module "@salesforce/apex/TOMSAssignMaintenanceController.readMSConfigTableWithFilter" {
  export default function readMSConfigTableWithFilter(param: {filterData: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getMaskSetTitle" {
  export default function getMaskSetTitle(): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getSearchMaskSetTitle" {
  export default function getSearchMaskSetTitle(param: {searchMaskSet: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.createConfigRecord" {
  export default function createConfigRecord(param: {newRecord: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getConfigRecord" {
  export default function getConfigRecord(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.updateConfigRecord" {
  export default function updateConfigRecord(param: {updateRec: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getTechGeoList" {
  export default function getTechGeoList(param: {tableType: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getCustomerShortnameList" {
  export default function getCustomerShortnameList(): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getSearchCustomerShortnameList" {
  export default function getSearchCustomerShortnameList(param: {searchCustomer: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.validateNSMARecord" {
  export default function validateNSMARecord(param: {nsmaRecord: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getFilteredMaskshopList" {
  export default function getFilteredMaskshopList(param: {fab: any, techGeo: any, tableType: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getValidCustomerShortnameList" {
  export default function getValidCustomerShortnameList(): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getSearchValidCustomerShortnameList" {
  export default function getSearchValidCustomerShortnameList(param: {searchValidCustomer: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.validateConfigRecord" {
  export default function validateConfigRecord(param: {configRec: any, configTable: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getFieldLabelsMessagesMaskshop" {
  export default function getFieldLabelsMessagesMaskshop(param: {formType: any, page: any}): Promise<any>;
}
declare module "@salesforce/apex/TOMSAssignMaintenanceController.getCustomerList" {
  export default function getCustomerList(param: {tableType: any}): Promise<any>;
}
