declare module "@salesforce/apex/TODesignEnablementSpecCls.getDesignEnbmtData" {
  export default function getDesignEnbmtData(param: {designManual: any}): Promise<any>;
}
