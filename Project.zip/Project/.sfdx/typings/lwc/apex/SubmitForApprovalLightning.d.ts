declare module "@salesforce/apex/SubmitForApprovalLightning.getInventory" {
  export default function getInventory(param: {inventoryId: any}): Promise<any>;
}
declare module "@salesforce/apex/SubmitForApprovalLightning.submitApprovalProcess" {
  export default function submitApprovalProcess(param: {inventoryId: any}): Promise<any>;
}
declare module "@salesforce/apex/SubmitForApprovalLightning.returnOpportunity" {
  export default function returnOpportunity(param: {inventoryId: any}): Promise<any>;
}
declare module "@salesforce/apex/SubmitForApprovalLightning.returnOpportunityprogram" {
  export default function returnOpportunityprogram(param: {inventoryId: any}): Promise<any>;
}
declare module "@salesforce/apex/SubmitForApprovalLightning.getAccountRecordType" {
  export default function getAccountRecordType(param: {inventoryId: any}): Promise<any>;
}
declare module "@salesforce/apex/SubmitForApprovalLightning.getSessionId" {
  export default function getSessionId(): Promise<any>;
}
