declare module "@salesforce/apex/TODRCConfiguration.__sfdc_masterOptionList" {
  export default function __sfdc_masterOptionList(param: {value: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.__sfdc_masterOptionList" {
  export default function __sfdc_masterOptionList(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getLoggedInUserInfo" {
  export default function getLoggedInUserInfo(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getLoggedInUserType" {
  export default function getLoggedInUserType(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.GetDRCMasterConfigWithOptions" {
  export default function GetDRCMasterConfigWithOptions(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.insertNewMasterConfig" {
  export default function insertNewMasterConfig(param: {newMasterConfig: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.insertNewOption" {
  export default function insertNewOption(param: {newOption: any, masterConfigId: any, status: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.updateOptionStatus" {
  export default function updateOptionStatus(param: {optionId: any, optionStatus: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getConfigMappingByOptionId" {
  export default function getConfigMappingByOptionId(param: {masterId: any, optionId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getSpecConfigMappingByConfigId" {
  export default function getSpecConfigMappingByConfigId(param: {configId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getMasterConfigMappingByMasterId" {
  export default function getMasterConfigMappingByMasterId(param: {masterId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getSpecMasterConfigMappingByConfigId" {
  export default function getSpecMasterConfigMappingByConfigId(param: {configId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.deleteMasterAndItsOptions" {
  export default function deleteMasterAndItsOptions(param: {masterId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.GetOptionsByMasterId" {
  export default function GetOptionsByMasterId(param: {masterId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getLatestOptionStatusByOptionId" {
  export default function getLatestOptionStatusByOptionId(param: {optionId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.GetDRCConfigTable" {
  export default function GetDRCConfigTable(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.insertConfig" {
  export default function insertConfig(param: {newConfig: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getOptionsByMasterTableId" {
  export default function getOptionsByMasterTableId(param: {masterTableId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.upsertConfigAndMappingTable" {
  export default function upsertConfigAndMappingTable(param: {buttonClicked: any, configTableId: any, configTableName: any, defaultTextId: any, defaultText: any, masterTableId: any, configTableState: any, configTableRemarks: any, newConfigMapping: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getDRCConfigMappings" {
  export default function getDRCConfigMappings(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getSpecTableMappingByConfigId" {
  export default function getSpecTableMappingByConfigId(param: {configId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.deactivateConfig" {
  export default function deactivateConfig(param: {configId: any, configState: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getDRCConfigMappingByConfigId" {
  export default function getDRCConfigMappingByConfigId(param: {configId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getPLMDesignManuals" {
  export default function getPLMDesignManuals(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getSpecConfigTable" {
  export default function getSpecConfigTable(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getSpecOptions" {
  export default function getSpecOptions(param: {lstDRCConfigIds: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.insertSpecConfig" {
  export default function insertSpecConfig(param: {newSpecConfig: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getNonUsedConfigTables" {
  export default function getNonUsedConfigTables(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getConfigListFromConfigOptionMapping" {
  export default function getConfigListFromConfigOptionMapping(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getConfigListFromSpecConfigMapping" {
  export default function getConfigListFromSpecConfigMapping(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getConfigListByMasterId" {
  export default function getConfigListByMasterId(param: {masterId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.updateSpecConfigTable" {
  export default function updateSpecConfigTable(param: {recordType: any, designManualId: any, designManualName: any, specConfigTableId: any, specConfigPrevVersion: any, specConfigCurrVersion: any, specConfigPrevState: any, specConfigCurrState: any, saveButtonType: any, specControlledNode: any, specConfigRemarks: any, specConfigMappingTable: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getSpecConfigBySpecId" {
  export default function getSpecConfigBySpecId(param: {specId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getSpecConfigMappingTableBySpecId" {
  export default function getSpecConfigMappingTableBySpecId(param: {specConfigId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getUserName" {
  export default function getUserName(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.deleteSpecConfigRecord" {
  export default function deleteSpecConfigRecord(param: {specConfigId: any, specConfigName: any, specConfigVersion: any, specConfigState: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.obsoleteSpecConfigRecord" {
  export default function obsoleteSpecConfigRecord(param: {specConfigId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getAccessSetupDetails" {
  export default function getAccessSetupDetails(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getMaskshopAccessSetupDetails" {
  export default function getMaskshopAccessSetupDetails(): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.deleteCondig" {
  export default function deleteCondig(param: {configId: any}): Promise<any>;
}
declare module "@salesforce/apex/TODRCConfiguration.getLatestConfig" {
  export default function getLatestConfig(): Promise<any>;
}
