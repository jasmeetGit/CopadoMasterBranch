declare module "@salesforce/apex/TODWCEmailNotifications.afterRevertSendEmailToPendingCustomers" {
  export default function afterRevertSendEmailToPendingCustomers(param: {dWCRecord: any}): Promise<any>;
}
declare module "@salesforce/apex/TODWCEmailNotifications.taskPendingFAEActionOnFCD" {
  export default function taskPendingFAEActionOnFCD(param: {dWCRecords: any, templateName: any}): Promise<any>;
}
