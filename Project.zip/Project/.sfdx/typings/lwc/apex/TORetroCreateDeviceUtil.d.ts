declare module "@salesforce/apex/TORetroCreateDeviceUtil.getMaskSetTitle" {
  export default function getMaskSetTitle(param: {formId: any}): Promise<any>;
}
declare module "@salesforce/apex/TORetroCreateDeviceUtil.updateMaskLayer" {
  export default function updateMaskLayer(param: {formId: any, retrofitfordevelopment: any, retrofitOptionsValue: any, maskLayerList: any, mstId: any, isSubmit: any, isUpdate: any}): Promise<any>;
}
declare module "@salesforce/apex/TORetroCreateDeviceUtil.getDeviceDetails" {
  export default function getDeviceDetails(param: {deviceId: any}): Promise<any>;
}
