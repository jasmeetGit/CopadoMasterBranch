declare module "@salesforce/resourceUrl/NDAMP1" {
    var NDAMP1: string;
    export default NDAMP1;
}