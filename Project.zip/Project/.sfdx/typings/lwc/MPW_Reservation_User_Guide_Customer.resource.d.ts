declare module "@salesforce/resourceUrl/MPW_Reservation_User_Guide_Customer" {
    var MPW_Reservation_User_Guide_Customer: string;
    export default MPW_Reservation_User_Guide_Customer;
}