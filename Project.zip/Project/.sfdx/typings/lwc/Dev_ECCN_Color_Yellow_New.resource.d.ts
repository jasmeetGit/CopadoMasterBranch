declare module "@salesforce/resourceUrl/Dev_ECCN_Color_Yellow_New" {
    var Dev_ECCN_Color_Yellow_New: string;
    export default Dev_ECCN_Color_Yellow_New;
}