declare module "@salesforce/resourceUrl/LotRequestS3of9" {
    var LotRequestS3of9: string;
    export default LotRequestS3of9;
}