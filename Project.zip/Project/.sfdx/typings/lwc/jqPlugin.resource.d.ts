declare module "@salesforce/resourceUrl/jqPlugin" {
    var jqPlugin: string;
    export default jqPlugin;
}