declare module "@salesforce/resourceUrl/DynamicTab" {
    var DynamicTab: string;
    export default DynamicTab;
}