declare module "@salesforce/resourceUrl/DS_Other_prepare_stage1" {
    var DS_Other_prepare_stage1: string;
    export default DS_Other_prepare_stage1;
}