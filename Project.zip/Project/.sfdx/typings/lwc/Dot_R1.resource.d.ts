declare module "@salesforce/resourceUrl/Dot_R1" {
    var Dot_R1: string;
    export default Dot_R1;
}