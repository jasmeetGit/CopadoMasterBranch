declare module "@salesforce/resourceUrl/LotRequestS2of9" {
    var LotRequestS2of9: string;
    export default LotRequestS2of9;
}