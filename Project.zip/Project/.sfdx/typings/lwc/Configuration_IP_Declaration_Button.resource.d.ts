declare module "@salesforce/resourceUrl/Configuration_IP_Declaration_Button" {
    var Configuration_IP_Declaration_Button: string;
    export default Configuration_IP_Declaration_Button;
}