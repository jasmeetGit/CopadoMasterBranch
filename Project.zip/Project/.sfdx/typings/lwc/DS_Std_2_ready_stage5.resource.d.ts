declare module "@salesforce/resourceUrl/DS_Std_2_ready_stage5" {
    var DS_Std_2_ready_stage5: string;
    export default DS_Std_2_ready_stage5;
}