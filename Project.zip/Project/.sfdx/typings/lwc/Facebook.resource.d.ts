declare module "@salesforce/resourceUrl/Facebook" {
    var Facebook: string;
    export default Facebook;
}