declare module "@salesforce/resourceUrl/DW_Progress_0" {
    var DW_Progress_0: string;
    export default DW_Progress_0;
}