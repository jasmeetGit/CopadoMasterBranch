declare module "@salesforce/resourceUrl/LotRequestS1of9" {
    var LotRequestS1of9: string;
    export default LotRequestS1of9;
}