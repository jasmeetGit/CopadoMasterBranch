declare module "@salesforce/resourceUrl/multiunselected" {
    var multiunselected: string;
    export default multiunselected;
}