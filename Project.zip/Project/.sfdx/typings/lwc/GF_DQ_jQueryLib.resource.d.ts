declare module "@salesforce/resourceUrl/GF_DQ_jQueryLib" {
    var GF_DQ_jQueryLib: string;
    export default GF_DQ_jQueryLib;
}