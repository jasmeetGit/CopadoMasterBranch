declare module "@salesforce/resourceUrl/Opty_Stage5" {
    var Opty_Stage5: string;
    export default Opty_Stage5;
}