declare module "@salesforce/resourceUrl/DS_Multi_DSGroup_stage3" {
    var DS_Multi_DSGroup_stage3: string;
    export default DS_Multi_DSGroup_stage3;
}