declare module "@salesforce/resourceUrl/NDAMP4" {
    var NDAMP4: string;
    export default NDAMP4;
}