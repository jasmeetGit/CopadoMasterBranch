declare module "@salesforce/resourceUrl/Loader" {
    var Loader: string;
    export default Loader;
}