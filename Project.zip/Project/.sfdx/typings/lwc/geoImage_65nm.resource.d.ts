declare module "@salesforce/resourceUrl/geoImage_65nm" {
    var geoImage_65nm: string;
    export default geoImage_65nm;
}