declare module "@salesforce/resourceUrl/NDAStdStage7" {
    var NDAStdStage7: string;
    export default NDAStdStage7;
}