declare module "@salesforce/resourceUrl/NDAStdStage6a" {
    var NDAStdStage6a: string;
    export default NDAStdStage6a;
}