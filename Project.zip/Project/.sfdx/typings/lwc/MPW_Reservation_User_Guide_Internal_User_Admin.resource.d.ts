declare module "@salesforce/resourceUrl/MPW_Reservation_User_Guide_Internal_User_Admin" {
    var MPW_Reservation_User_Guide_Internal_User_Admin: string;
    export default MPW_Reservation_User_Guide_Internal_User_Admin;
}