declare module "@salesforce/resourceUrl/Button_Generate" {
    var Button_Generate: string;
    export default Button_Generate;
}