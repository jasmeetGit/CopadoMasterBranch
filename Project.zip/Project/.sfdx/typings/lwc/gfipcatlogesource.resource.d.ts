declare module "@salesforce/resourceUrl/gfipcatlogesource" {
    var gfipcatlogesource: string;
    export default gfipcatlogesource;
}