declare module "@salesforce/resourceUrl/NDAMPStage2gi" {
    var NDAMPStage2gi: string;
    export default NDAMPStage2gi;
}