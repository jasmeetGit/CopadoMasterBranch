declare module "@salesforce/resourceUrl/BrowseCatalog" {
    var BrowseCatalog: string;
    export default BrowseCatalog;
}