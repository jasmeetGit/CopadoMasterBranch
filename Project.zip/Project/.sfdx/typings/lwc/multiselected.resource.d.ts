declare module "@salesforce/resourceUrl/multiselected" {
    var multiselected: string;
    export default multiselected;
}