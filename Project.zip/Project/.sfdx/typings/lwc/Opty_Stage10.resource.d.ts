declare module "@salesforce/resourceUrl/Opty_Stage10" {
    var Opty_Stage10: string;
    export default Opty_Stage10;
}