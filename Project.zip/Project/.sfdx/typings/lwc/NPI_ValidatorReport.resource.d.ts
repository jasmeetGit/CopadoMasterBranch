declare module "@salesforce/resourceUrl/NPI_ValidatorReport" {
    var NPI_ValidatorReport: string;
    export default NPI_ValidatorReport;
}