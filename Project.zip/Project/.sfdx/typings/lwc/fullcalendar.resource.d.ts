declare module "@salesforce/resourceUrl/fullcalendar" {
    var fullcalendar: string;
    export default fullcalendar;
}