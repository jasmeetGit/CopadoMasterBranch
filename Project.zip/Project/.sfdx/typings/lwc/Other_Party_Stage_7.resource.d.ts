declare module "@salesforce/resourceUrl/Other_Party_Stage_7" {
    var Other_Party_Stage_7: string;
    export default Other_Party_Stage_7;
}