declare module "@salesforce/resourceUrl/Cancelled_GN_NDA" {
    var Cancelled_GN_NDA: string;
    export default Cancelled_GN_NDA;
}