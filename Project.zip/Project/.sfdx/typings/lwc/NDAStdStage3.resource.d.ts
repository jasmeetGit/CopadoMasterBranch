declare module "@salesforce/resourceUrl/NDAStdStage3" {
    var NDAStdStage3: string;
    export default NDAStdStage3;
}