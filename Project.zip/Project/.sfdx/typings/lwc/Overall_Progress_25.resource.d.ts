declare module "@salesforce/resourceUrl/Overall_Progress_25" {
    var Overall_Progress_25: string;
    export default Overall_Progress_25;
}