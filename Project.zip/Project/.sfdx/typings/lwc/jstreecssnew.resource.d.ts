declare module "@salesforce/resourceUrl/jstreecssnew" {
    var jstreecssnew: string;
    export default jstreecssnew;
}