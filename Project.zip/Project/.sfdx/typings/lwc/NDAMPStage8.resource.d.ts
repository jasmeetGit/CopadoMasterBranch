declare module "@salesforce/resourceUrl/NDAMPStage8" {
    var NDAMPStage8: string;
    export default NDAMPStage8;
}