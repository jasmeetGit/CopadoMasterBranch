declare module "@salesforce/resourceUrl/Button_Generate_XL" {
    var Button_Generate_XL: string;
    export default Button_Generate_XL;
}