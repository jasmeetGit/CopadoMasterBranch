declare module "@salesforce/resourceUrl/MPWRelatedJS" {
    var MPWRelatedJS: string;
    export default MPWRelatedJS;
}