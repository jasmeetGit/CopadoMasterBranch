declare module "@salesforce/resourceUrl/gf" {
    var gf: string;
    export default gf;
}