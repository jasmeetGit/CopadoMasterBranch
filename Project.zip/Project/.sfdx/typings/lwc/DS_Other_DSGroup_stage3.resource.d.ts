declare module "@salesforce/resourceUrl/DS_Other_DSGroup_stage3" {
    var DS_Other_DSGroup_stage3: string;
    export default DS_Other_DSGroup_stage3;
}