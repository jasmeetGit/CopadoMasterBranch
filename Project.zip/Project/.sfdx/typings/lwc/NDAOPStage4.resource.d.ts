declare module "@salesforce/resourceUrl/NDAOPStage4" {
    var NDAOPStage4: string;
    export default NDAOPStage4;
}