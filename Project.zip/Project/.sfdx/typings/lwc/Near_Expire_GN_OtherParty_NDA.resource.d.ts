declare module "@salesforce/resourceUrl/Near_Expire_GN_OtherParty_NDA" {
    var Near_Expire_GN_OtherParty_NDA: string;
    export default Near_Expire_GN_OtherParty_NDA;
}