declare module "@salesforce/resourceUrl/DS_Other_cancelled_stage7" {
    var DS_Other_cancelled_stage7: string;
    export default DS_Other_cancelled_stage7;
}