declare module "@salesforce/resourceUrl/NDAOPStageNew1" {
    var NDAOPStageNew1: string;
    export default NDAOPStageNew1;
}