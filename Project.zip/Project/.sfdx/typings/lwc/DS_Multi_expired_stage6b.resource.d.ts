declare module "@salesforce/resourceUrl/DS_Multi_expired_stage6b" {
    var DS_Multi_expired_stage6b: string;
    export default DS_Multi_expired_stage6b;
}