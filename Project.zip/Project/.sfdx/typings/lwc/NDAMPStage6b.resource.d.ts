declare module "@salesforce/resourceUrl/NDAMPStage6b" {
    var NDAMPStage6b: string;
    export default NDAMPStage6b;
}