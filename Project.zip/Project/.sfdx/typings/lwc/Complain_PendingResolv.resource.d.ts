declare module "@salesforce/resourceUrl/Complain_PendingResolv" {
    var Complain_PendingResolv: string;
    export default Complain_PendingResolv;
}