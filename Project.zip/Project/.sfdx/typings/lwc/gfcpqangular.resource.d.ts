declare module "@salesforce/resourceUrl/gfcpqangular" {
    var gfcpqangular: string;
    export default gfcpqangular;
}