declare module "@salesforce/resourceUrl/CustomerReport_StandardSubscription_select2container" {
    var CustomerReport_StandardSubscription_select2container: string;
    export default CustomerReport_StandardSubscription_select2container;
}