declare module "@salesforce/resourceUrl/DW_Progress_100" {
    var DW_Progress_100: string;
    export default DW_Progress_100;
}