declare module "@salesforce/resourceUrl/downarrow" {
    var downarrow: string;
    export default downarrow;
}