declare module "@salesforce/resourceUrl/GF_DQ_ShippingReportLib" {
    var GF_DQ_ShippingReportLib: string;
    export default GF_DQ_ShippingReportLib;
}