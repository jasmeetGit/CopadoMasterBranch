declare module "@salesforce/resourceUrl/Account_Progress_3" {
    var Account_Progress_3: string;
    export default Account_Progress_3;
}