declare module "@salesforce/resourceUrl/Complain_Acknowledged" {
    var Complain_Acknowledged: string;
    export default Complain_Acknowledged;
}