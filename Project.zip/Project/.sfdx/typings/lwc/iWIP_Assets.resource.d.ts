declare module "@salesforce/resourceUrl/iWIP_Assets" {
    var iWIP_Assets: string;
    export default iWIP_Assets;
}