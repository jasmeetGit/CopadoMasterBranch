declare module "@salesforce/resourceUrl/BnP_Route_Start_Status" {
    var BnP_Route_Start_Status: string;
    export default BnP_Route_Start_Status;
}