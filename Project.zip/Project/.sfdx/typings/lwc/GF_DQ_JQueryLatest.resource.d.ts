declare module "@salesforce/resourceUrl/GF_DQ_JQueryLatest" {
    var GF_DQ_JQueryLatest: string;
    export default GF_DQ_JQueryLatest;
}