declare module "@salesforce/resourceUrl/ipcatlogsupportingcss" {
    var ipcatlogsupportingcss: string;
    export default ipcatlogsupportingcss;
}