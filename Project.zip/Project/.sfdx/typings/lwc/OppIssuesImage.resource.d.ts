declare module "@salesforce/resourceUrl/OppIssuesImage" {
    var OppIssuesImage: string;
    export default OppIssuesImage;
}