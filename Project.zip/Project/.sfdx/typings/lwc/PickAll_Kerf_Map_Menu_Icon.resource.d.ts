declare module "@salesforce/resourceUrl/PickAll_Kerf_Map_Menu_Icon" {
    var PickAll_Kerf_Map_Menu_Icon: string;
    export default PickAll_Kerf_Map_Menu_Icon;
}