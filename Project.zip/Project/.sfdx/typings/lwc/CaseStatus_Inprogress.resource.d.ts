declare module "@salesforce/resourceUrl/CaseStatus_Inprogress" {
    var CaseStatus_Inprogress: string;
    export default CaseStatus_Inprogress;
}