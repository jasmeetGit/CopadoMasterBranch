declare module "@salesforce/resourceUrl/CaseStatus_Reassigned" {
    var CaseStatus_Reassigned: string;
    export default CaseStatus_Reassigned;
}