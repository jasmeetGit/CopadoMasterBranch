declare module "@salesforce/resourceUrl/Cancelled_GN_OtherParty_NDA" {
    var Cancelled_GN_OtherParty_NDA: string;
    export default Cancelled_GN_OtherParty_NDA;
}