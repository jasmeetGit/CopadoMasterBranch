declare module "@salesforce/resourceUrl/CaseStatus_OnHold" {
    var CaseStatus_OnHold: string;
    export default CaseStatus_OnHold;
}