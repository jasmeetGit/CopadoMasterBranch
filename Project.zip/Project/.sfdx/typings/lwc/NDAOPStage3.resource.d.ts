declare module "@salesforce/resourceUrl/NDAOPStage3" {
    var NDAOPStage3: string;
    export default NDAOPStage3;
}