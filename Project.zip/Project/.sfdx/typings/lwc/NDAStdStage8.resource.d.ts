declare module "@salesforce/resourceUrl/NDAStdStage8" {
    var NDAStdStage8: string;
    export default NDAStdStage8;
}