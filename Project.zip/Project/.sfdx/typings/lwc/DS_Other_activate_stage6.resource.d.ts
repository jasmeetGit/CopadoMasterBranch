declare module "@salesforce/resourceUrl/DS_Other_activate_stage6" {
    var DS_Other_activate_stage6: string;
    export default DS_Other_activate_stage6;
}