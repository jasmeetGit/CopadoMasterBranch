declare module "@salesforce/resourceUrl/InformationRequired" {
    var InformationRequired: string;
    export default InformationRequired;
}