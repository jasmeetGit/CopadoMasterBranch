declare module "@salesforce/resourceUrl/NDAOP8" {
    var NDAOP8: string;
    export default NDAOP8;
}