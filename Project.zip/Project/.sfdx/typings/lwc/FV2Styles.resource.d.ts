declare module "@salesforce/resourceUrl/FV2Styles" {
    var FV2Styles: string;
    export default FV2Styles;
}