declare module "@salesforce/resourceUrl/Gfllogo" {
    var Gfllogo: string;
    export default Gfllogo;
}