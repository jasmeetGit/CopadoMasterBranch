declare module "@salesforce/resourceUrl/Opty_Stage9" {
    var Opty_Stage9: string;
    export default Opty_Stage9;
}