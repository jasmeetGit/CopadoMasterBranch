declare module "@salesforce/resourceUrl/NDAMP3b" {
    var NDAMP3b: string;
    export default NDAMP3b;
}