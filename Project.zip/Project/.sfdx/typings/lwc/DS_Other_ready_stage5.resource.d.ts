declare module "@salesforce/resourceUrl/DS_Other_ready_stage5" {
    var DS_Other_ready_stage5: string;
    export default DS_Other_ready_stage5;
}