declare module "@salesforce/resourceUrl/Account_Y_trending_Up" {
    var Account_Y_trending_Up: string;
    export default Account_Y_trending_Up;
}