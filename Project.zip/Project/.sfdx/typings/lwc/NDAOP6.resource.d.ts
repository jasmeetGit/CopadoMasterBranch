declare module "@salesforce/resourceUrl/NDAOP6" {
    var NDAOP6: string;
    export default NDAOP6;
}