declare module "@salesforce/resourceUrl/FoundryServicePrices_new" {
    var FoundryServicePrices_new: string;
    export default FoundryServicePrices_new;
}