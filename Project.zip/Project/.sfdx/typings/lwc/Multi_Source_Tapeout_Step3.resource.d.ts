declare module "@salesforce/resourceUrl/Multi_Source_Tapeout_Step3" {
    var Multi_Source_Tapeout_Step3: string;
    export default Multi_Source_Tapeout_Step3;
}