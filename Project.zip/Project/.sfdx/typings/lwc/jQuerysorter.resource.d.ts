declare module "@salesforce/resourceUrl/jQuerysorter" {
    var jQuerysorter: string;
    export default jQuerysorter;
}