declare module "@salesforce/resourceUrl/NDAOP3a" {
    var NDAOP3a: string;
    export default NDAOP3a;
}