declare module "@salesforce/resourceUrl/jqueryuiscss19" {
    var jqueryuiscss19: string;
    export default jqueryuiscss19;
}