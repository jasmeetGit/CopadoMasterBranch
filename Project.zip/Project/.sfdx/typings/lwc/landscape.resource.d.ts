declare module "@salesforce/resourceUrl/landscape" {
    var landscape: string;
    export default landscape;
}