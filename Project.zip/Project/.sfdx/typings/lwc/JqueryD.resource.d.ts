declare module "@salesforce/resourceUrl/JqueryD" {
    var JqueryD: string;
    export default JqueryD;
}