declare module "@salesforce/resourceUrl/NDAStd6" {
    var NDAStd6: string;
    export default NDAStd6;
}