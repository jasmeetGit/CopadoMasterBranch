declare module "@salesforce/resourceUrl/DWCStreaming" {
    var DWCStreaming: string;
    export default DWCStreaming;
}