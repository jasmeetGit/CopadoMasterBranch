declare module "@salesforce/resourceUrl/BnP_Route_InProgress_Status" {
    var BnP_Route_InProgress_Status: string;
    export default BnP_Route_InProgress_Status;
}