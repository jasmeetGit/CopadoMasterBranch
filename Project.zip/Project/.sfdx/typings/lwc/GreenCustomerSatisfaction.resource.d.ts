declare module "@salesforce/resourceUrl/GreenCustomerSatisfaction" {
    var GreenCustomerSatisfaction: string;
    export default GreenCustomerSatisfaction;
}