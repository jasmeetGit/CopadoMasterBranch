declare module "@salesforce/resourceUrl/PickAllKerfMap" {
    var PickAllKerfMap: string;
    export default PickAllKerfMap;
}