declare module "@salesforce/resourceUrl/geoImage_55nm" {
    var geoImage_55nm: string;
    export default geoImage_55nm;
}