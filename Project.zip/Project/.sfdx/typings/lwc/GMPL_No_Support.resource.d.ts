declare module "@salesforce/resourceUrl/GMPL_No_Support" {
    var GMPL_No_Support: string;
    export default GMPL_No_Support;
}