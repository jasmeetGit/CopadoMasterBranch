declare module "@salesforce/resourceUrl/NDAStd5" {
    var NDAStd5: string;
    export default NDAStd5;
}