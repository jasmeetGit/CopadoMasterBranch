declare module "@salesforce/resourceUrl/ConnectionJS" {
    var ConnectionJS: string;
    export default ConnectionJS;
}