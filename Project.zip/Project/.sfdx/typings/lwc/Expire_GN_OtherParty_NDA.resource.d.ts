declare module "@salesforce/resourceUrl/Expire_GN_OtherParty_NDA" {
    var Expire_GN_OtherParty_NDA: string;
    export default Expire_GN_OtherParty_NDA;
}