declare module "@salesforce/resourceUrl/Arrows" {
    var Arrows: string;
    export default Arrows;
}