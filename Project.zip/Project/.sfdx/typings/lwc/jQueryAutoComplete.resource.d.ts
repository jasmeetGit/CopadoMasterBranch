declare module "@salesforce/resourceUrl/jQueryAutoComplete" {
    var jQueryAutoComplete: string;
    export default jQueryAutoComplete;
}