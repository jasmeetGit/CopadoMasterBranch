declare module "@salesforce/resourceUrl/NDAMPStage2" {
    var NDAMPStage2: string;
    export default NDAMPStage2;
}