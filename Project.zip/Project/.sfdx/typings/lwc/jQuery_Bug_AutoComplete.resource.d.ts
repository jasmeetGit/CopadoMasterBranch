declare module "@salesforce/resourceUrl/jQuery_Bug_AutoComplete" {
    var jQuery_Bug_AutoComplete: string;
    export default jQuery_Bug_AutoComplete;
}