declare module "@salesforce/resourceUrl/atlasCss" {
    var atlasCss: string;
    export default atlasCss;
}