declare module "@salesforce/resourceUrl/DS_Multi_cancelled_stage7" {
    var DS_Multi_cancelled_stage7: string;
    export default DS_Multi_cancelled_stage7;
}