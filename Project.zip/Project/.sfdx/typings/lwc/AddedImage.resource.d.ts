declare module "@salesforce/resourceUrl/AddedImage" {
    var AddedImage: string;
    export default AddedImage;
}