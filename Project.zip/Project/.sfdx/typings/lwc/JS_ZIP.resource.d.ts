declare module "@salesforce/resourceUrl/JS_ZIP" {
    var JS_ZIP: string;
    export default JS_ZIP;
}