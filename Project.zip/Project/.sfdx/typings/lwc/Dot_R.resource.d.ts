declare module "@salesforce/resourceUrl/Dot_R" {
    var Dot_R: string;
    export default Dot_R;
}