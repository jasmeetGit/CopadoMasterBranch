declare module "@salesforce/resourceUrl/Expire_Set" {
    var Expire_Set: string;
    export default Expire_Set;
}