declare module "@salesforce/resourceUrl/BnP_QuoteAccept" {
    var BnP_QuoteAccept: string;
    export default BnP_QuoteAccept;
}