declare module "@salesforce/resourceUrl/additional_requirement" {
    var additional_requirement: string;
    export default additional_requirement;
}