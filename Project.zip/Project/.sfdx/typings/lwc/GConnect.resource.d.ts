declare module "@salesforce/resourceUrl/GConnect" {
    var GConnect: string;
    export default GConnect;
}