declare module "@salesforce/resourceUrl/NDAMPStage3a" {
    var NDAMPStage3a: string;
    export default NDAMPStage3a;
}