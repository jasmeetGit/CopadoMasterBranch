declare module "@salesforce/resourceUrl/jquerymin" {
    var jquerymin: string;
    export default jquerymin;
}