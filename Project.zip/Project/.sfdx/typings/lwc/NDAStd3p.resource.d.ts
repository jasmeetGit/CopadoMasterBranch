declare module "@salesforce/resourceUrl/NDAStd3p" {
    var NDAStd3p: string;
    export default NDAStd3p;
}