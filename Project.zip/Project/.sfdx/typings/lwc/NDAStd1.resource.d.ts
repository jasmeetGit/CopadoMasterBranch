declare module "@salesforce/resourceUrl/NDAStd1" {
    var NDAStd1: string;
    export default NDAStd1;
}