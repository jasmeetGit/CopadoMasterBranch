declare module "@salesforce/resourceUrl/DS_Multi_terminated_stage8" {
    var DS_Multi_terminated_stage8: string;
    export default DS_Multi_terminated_stage8;
}