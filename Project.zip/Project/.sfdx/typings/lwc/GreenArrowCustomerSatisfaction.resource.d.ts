declare module "@salesforce/resourceUrl/GreenArrowCustomerSatisfaction" {
    var GreenArrowCustomerSatisfaction: string;
    export default GreenArrowCustomerSatisfaction;
}