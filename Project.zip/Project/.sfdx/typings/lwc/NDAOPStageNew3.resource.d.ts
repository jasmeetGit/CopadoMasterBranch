declare module "@salesforce/resourceUrl/NDAOPStageNew3" {
    var NDAOPStageNew3: string;
    export default NDAOPStageNew3;
}