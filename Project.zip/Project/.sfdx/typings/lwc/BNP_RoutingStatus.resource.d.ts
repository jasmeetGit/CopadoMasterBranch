declare module "@salesforce/resourceUrl/BNP_RoutingStatus" {
    var BNP_RoutingStatus: string;
    export default BNP_RoutingStatus;
}