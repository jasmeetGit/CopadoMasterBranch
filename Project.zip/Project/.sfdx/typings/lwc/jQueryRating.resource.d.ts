declare module "@salesforce/resourceUrl/jQueryRating" {
    var jQueryRating: string;
    export default jQueryRating;
}