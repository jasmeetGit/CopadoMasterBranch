declare module "@salesforce/resourceUrl/MaskLayerUpload" {
    var MaskLayerUpload: string;
    export default MaskLayerUpload;
}