declare module "@salesforce/resourceUrl/jQueryUI_1_11_2" {
    var jQueryUI_1_11_2: string;
    export default jQueryUI_1_11_2;
}