declare module "@salesforce/resourceUrl/LotRequestGood" {
    var LotRequestGood: string;
    export default LotRequestGood;
}