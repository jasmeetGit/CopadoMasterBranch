declare module "@salesforce/resourceUrl/Opty_Stage4" {
    var Opty_Stage4: string;
    export default Opty_Stage4;
}