declare module "@salesforce/resourceUrl/NDAStd8" {
    var NDAStd8: string;
    export default NDAStd8;
}