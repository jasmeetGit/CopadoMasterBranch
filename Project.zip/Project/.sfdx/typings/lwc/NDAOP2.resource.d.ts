declare module "@salesforce/resourceUrl/NDAOP2" {
    var NDAOP2: string;
    export default NDAOP2;
}