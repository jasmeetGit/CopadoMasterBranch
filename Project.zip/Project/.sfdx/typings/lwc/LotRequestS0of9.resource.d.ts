declare module "@salesforce/resourceUrl/LotRequestS0of9" {
    var LotRequestS0of9: string;
    export default LotRequestS0of9;
}