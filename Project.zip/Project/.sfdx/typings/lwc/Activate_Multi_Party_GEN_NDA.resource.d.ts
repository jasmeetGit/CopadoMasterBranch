declare module "@salesforce/resourceUrl/Activate_Multi_Party_GEN_NDA" {
    var Activate_Multi_Party_GEN_NDA: string;
    export default Activate_Multi_Party_GEN_NDA;
}