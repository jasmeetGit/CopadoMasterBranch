declare module "@salesforce/resourceUrl/NDAStd6a" {
    var NDAStd6a: string;
    export default NDAStd6a;
}