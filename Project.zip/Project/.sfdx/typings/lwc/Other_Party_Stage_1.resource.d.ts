declare module "@salesforce/resourceUrl/Other_Party_Stage_1" {
    var Other_Party_Stage_1: string;
    export default Other_Party_Stage_1;
}