declare module "@salesforce/resourceUrl/PEOL" {
    var PEOL: string;
    export default PEOL;
}