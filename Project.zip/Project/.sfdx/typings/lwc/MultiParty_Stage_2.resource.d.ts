declare module "@salesforce/resourceUrl/MultiParty_Stage_2" {
    var MultiParty_Stage_2: string;
    export default MultiParty_Stage_2;
}