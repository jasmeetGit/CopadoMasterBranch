declare module "@salesforce/resourceUrl/jQuery_FoundryView2" {
    var jQuery_FoundryView2: string;
    export default jQuery_FoundryView2;
}