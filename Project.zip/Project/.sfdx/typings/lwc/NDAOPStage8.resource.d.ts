declare module "@salesforce/resourceUrl/NDAOPStage8" {
    var NDAOPStage8: string;
    export default NDAOPStage8;
}