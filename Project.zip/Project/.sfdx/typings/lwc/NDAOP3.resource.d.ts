declare module "@salesforce/resourceUrl/NDAOP3" {
    var NDAOP3: string;
    export default NDAOP3;
}