declare module "@salesforce/resourceUrl/NDAOP5" {
    var NDAOP5: string;
    export default NDAOP5;
}