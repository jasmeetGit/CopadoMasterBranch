declare module "@salesforce/resourceUrl/NDAMPStage6a" {
    var NDAMPStage6a: string;
    export default NDAMPStage6a;
}