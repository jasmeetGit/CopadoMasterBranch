declare module "@salesforce/resourceUrl/Cancelled_Multi_Party_GEN_NDA" {
    var Cancelled_Multi_Party_GEN_NDA: string;
    export default Cancelled_Multi_Party_GEN_NDA;
}