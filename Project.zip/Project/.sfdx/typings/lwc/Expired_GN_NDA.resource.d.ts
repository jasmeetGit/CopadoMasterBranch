declare module "@salesforce/resourceUrl/Expired_GN_NDA" {
    var Expired_GN_NDA: string;
    export default Expired_GN_NDA;
}