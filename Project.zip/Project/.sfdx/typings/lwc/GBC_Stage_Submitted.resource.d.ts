declare module "@salesforce/resourceUrl/GBC_Stage_Submitted" {
    var GBC_Stage_Submitted: string;
    export default GBC_Stage_Submitted;
}