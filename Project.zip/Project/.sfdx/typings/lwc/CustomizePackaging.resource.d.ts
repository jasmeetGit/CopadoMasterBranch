declare module "@salesforce/resourceUrl/CustomizePackaging" {
    var CustomizePackaging: string;
    export default CustomizePackaging;
}