declare module "@salesforce/resourceUrl/iWIP_Menu_Icon" {
    var iWIP_Menu_Icon: string;
    export default iWIP_Menu_Icon;
}