declare module "@salesforce/resourceUrl/AtlasProcessImage" {
    var AtlasProcessImage: string;
    export default AtlasProcessImage;
}