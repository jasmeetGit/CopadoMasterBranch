declare module "@salesforce/resourceUrl/advancedpdfresource" {
    var advancedpdfresource: string;
    export default advancedpdfresource;
}