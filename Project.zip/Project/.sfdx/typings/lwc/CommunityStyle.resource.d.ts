declare module "@salesforce/resourceUrl/CommunityStyle" {
    var CommunityStyle: string;
    export default CommunityStyle;
}