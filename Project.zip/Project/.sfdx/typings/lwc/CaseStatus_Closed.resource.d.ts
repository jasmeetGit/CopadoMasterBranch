declare module "@salesforce/resourceUrl/CaseStatus_Closed" {
    var CaseStatus_Closed: string;
    export default CaseStatus_Closed;
}