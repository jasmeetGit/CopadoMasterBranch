declare module "@salesforce/resourceUrl/gfcpqserviceconsoleresource" {
    var gfcpqserviceconsoleresource: string;
    export default gfcpqserviceconsoleresource;
}