declare module "@salesforce/resourceUrl/Activatel_Step_GN_NDA" {
    var Activatel_Step_GN_NDA: string;
    export default Activatel_Step_GN_NDA;
}