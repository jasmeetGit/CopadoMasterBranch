declare module "@salesforce/resourceUrl/img40px" {
    var img40px: string;
    export default img40px;
}