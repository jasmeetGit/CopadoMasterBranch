declare module "@salesforce/resourceUrl/IPDecAttentionRequired" {
    var IPDecAttentionRequired: string;
    export default IPDecAttentionRequired;
}