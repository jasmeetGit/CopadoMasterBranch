declare module "@salesforce/resourceUrl/AtlasPrintImage01" {
    var AtlasPrintImage01: string;
    export default AtlasPrintImage01;
}