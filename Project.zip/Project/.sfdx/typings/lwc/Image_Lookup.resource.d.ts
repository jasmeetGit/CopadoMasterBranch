declare module "@salesforce/resourceUrl/Image_Lookup" {
    var Image_Lookup: string;
    export default Image_Lookup;
}