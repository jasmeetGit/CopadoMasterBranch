declare module "@salesforce/resourceUrl/DraftWatermark" {
    var DraftWatermark: string;
    export default DraftWatermark;
}