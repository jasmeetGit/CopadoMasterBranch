declare module "@salesforce/resourceUrl/DS_Other_signature_stage4" {
    var DS_Other_signature_stage4: string;
    export default DS_Other_signature_stage4;
}