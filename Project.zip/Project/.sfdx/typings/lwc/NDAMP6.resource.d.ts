declare module "@salesforce/resourceUrl/NDAMP6" {
    var NDAMP6: string;
    export default NDAMP6;
}