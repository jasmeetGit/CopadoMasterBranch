declare module "@salesforce/resourceUrl/LotRequestS8of9" {
    var LotRequestS8of9: string;
    export default LotRequestS8of9;
}