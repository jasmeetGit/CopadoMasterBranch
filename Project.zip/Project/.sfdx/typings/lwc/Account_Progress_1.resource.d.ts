declare module "@salesforce/resourceUrl/Account_Progress_1" {
    var Account_Progress_1: string;
    export default Account_Progress_1;
}