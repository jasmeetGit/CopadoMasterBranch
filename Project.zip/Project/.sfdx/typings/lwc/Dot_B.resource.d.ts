declare module "@salesforce/resourceUrl/Dot_B" {
    var Dot_B: string;
    export default Dot_B;
}