declare module "@salesforce/resourceUrl/jqueryuijs" {
    var jqueryuijs: string;
    export default jqueryuijs;
}