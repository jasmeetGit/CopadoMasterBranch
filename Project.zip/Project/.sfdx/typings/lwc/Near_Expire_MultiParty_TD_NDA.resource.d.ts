declare module "@salesforce/resourceUrl/Near_Expire_MultiParty_TD_NDA" {
    var Near_Expire_MultiParty_TD_NDA: string;
    export default Near_Expire_MultiParty_TD_NDA;
}