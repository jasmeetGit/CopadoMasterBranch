declare module "@salesforce/resourceUrl/JSCalendar" {
    var JSCalendar: string;
    export default JSCalendar;
}