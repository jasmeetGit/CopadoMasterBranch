declare module "@salesforce/resourceUrl/Other_Party_Stage_6" {
    var Other_Party_Stage_6: string;
    export default Other_Party_Stage_6;
}