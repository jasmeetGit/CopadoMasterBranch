declare module "@salesforce/resourceUrl/BnP_GreenFlag" {
    var BnP_GreenFlag: string;
    export default BnP_GreenFlag;
}