declare module "@salesforce/resourceUrl/MPW_Turnkey_PreAlert_Form" {
    var MPW_Turnkey_PreAlert_Form: string;
    export default MPW_Turnkey_PreAlert_Form;
}