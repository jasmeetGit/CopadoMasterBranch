declare module "@salesforce/resourceUrl/Activate_GN_OtherParty_NDA" {
    var Activate_GN_OtherParty_NDA: string;
    export default Activate_GN_OtherParty_NDA;
}