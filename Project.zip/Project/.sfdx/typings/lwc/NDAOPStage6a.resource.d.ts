declare module "@salesforce/resourceUrl/NDAOPStage6a" {
    var NDAOPStage6a: string;
    export default NDAOPStage6a;
}