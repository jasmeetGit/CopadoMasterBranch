declare module "@salesforce/resourceUrl/NDAStdStage5" {
    var NDAStdStage5: string;
    export default NDAStdStage5;
}