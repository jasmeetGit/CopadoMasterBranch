declare module "@salesforce/resourceUrl/cpqservice" {
    var cpqservice: string;
    export default cpqservice;
}