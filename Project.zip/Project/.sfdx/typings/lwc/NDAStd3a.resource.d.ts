declare module "@salesforce/resourceUrl/NDAStd3a" {
    var NDAStd3a: string;
    export default NDAStd3a;
}