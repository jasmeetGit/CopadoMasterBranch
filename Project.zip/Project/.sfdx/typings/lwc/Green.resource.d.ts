declare module "@salesforce/resourceUrl/Green" {
    var Green: string;
    export default Green;
}