declare module "@salesforce/resourceUrl/MPWTermsAndCondations" {
    var MPWTermsAndCondations: string;
    export default MPWTermsAndCondations;
}