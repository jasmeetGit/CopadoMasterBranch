declare module "@salesforce/resourceUrl/DS_Multi_review_stage2" {
    var DS_Multi_review_stage2: string;
    export default DS_Multi_review_stage2;
}