declare module "@salesforce/resourceUrl/BrowseCatalogPDKChanged" {
    var BrowseCatalogPDKChanged: string;
    export default BrowseCatalogPDKChanged;
}