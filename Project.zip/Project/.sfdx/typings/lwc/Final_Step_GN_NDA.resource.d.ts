declare module "@salesforce/resourceUrl/Final_Step_GN_NDA" {
    var Final_Step_GN_NDA: string;
    export default Final_Step_GN_NDA;
}