declare module "@salesforce/resourceUrl/gfcal" {
    var gfcal: string;
    export default gfcal;
}