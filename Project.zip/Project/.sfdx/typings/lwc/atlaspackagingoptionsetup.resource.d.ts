declare module "@salesforce/resourceUrl/atlaspackagingoptionsetup" {
    var atlaspackagingoptionsetup: string;
    export default atlaspackagingoptionsetup;
}