declare module "@salesforce/resourceUrl/geoImage_160nm" {
    var geoImage_160nm: string;
    export default geoImage_160nm;
}