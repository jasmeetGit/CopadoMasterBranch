declare module "@salesforce/resourceUrl/BlueLoaderImage" {
    var BlueLoaderImage: string;
    export default BlueLoaderImage;
}