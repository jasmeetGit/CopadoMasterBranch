declare module "@salesforce/resourceUrl/MDevice_Lib" {
    var MDevice_Lib: string;
    export default MDevice_Lib;
}