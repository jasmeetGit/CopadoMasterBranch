declare module "@salesforce/resourceUrl/JSFile_ROSVF_SearchReticlesGFForm" {
    var JSFile_ROSVF_SearchReticlesGFForm: string;
    export default JSFile_ROSVF_SearchReticlesGFForm;
}