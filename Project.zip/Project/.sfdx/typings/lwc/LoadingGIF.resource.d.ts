declare module "@salesforce/resourceUrl/LoadingGIF" {
    var LoadingGIF: string;
    export default LoadingGIF;
}