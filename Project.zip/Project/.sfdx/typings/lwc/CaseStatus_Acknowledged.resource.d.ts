declare module "@salesforce/resourceUrl/CaseStatus_Acknowledged" {
    var CaseStatus_Acknowledged: string;
    export default CaseStatus_Acknowledged;
}