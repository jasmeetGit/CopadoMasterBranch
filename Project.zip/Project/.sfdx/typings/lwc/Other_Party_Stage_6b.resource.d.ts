declare module "@salesforce/resourceUrl/Other_Party_Stage_6b" {
    var Other_Party_Stage_6b: string;
    export default Other_Party_Stage_6b;
}