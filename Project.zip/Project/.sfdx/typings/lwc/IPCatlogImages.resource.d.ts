declare module "@salesforce/resourceUrl/IPCatlogImages" {
    var IPCatlogImages: string;
    export default IPCatlogImages;
}