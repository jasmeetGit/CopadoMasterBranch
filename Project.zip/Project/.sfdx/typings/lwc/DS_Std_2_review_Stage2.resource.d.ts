declare module "@salesforce/resourceUrl/DS_Std_2_review_Stage2" {
    var DS_Std_2_review_Stage2: string;
    export default DS_Std_2_review_Stage2;
}