declare module "@salesforce/resourceUrl/GBC_Stage_Rejected" {
    var GBC_Stage_Rejected: string;
    export default GBC_Stage_Rejected;
}