declare module "@salesforce/resourceUrl/NDAOPStage1" {
    var NDAOPStage1: string;
    export default NDAOPStage1;
}