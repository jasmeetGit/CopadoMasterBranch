declare module "@salesforce/resourceUrl/MultiParty_Stage_8" {
    var MultiParty_Stage_8: string;
    export default MultiParty_Stage_8;
}