declare module "@salesforce/resourceUrl/ChecklistResouces" {
    var ChecklistResouces: string;
    export default ChecklistResouces;
}