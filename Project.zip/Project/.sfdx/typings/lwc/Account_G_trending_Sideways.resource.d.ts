declare module "@salesforce/resourceUrl/Account_G_trending_Sideways" {
    var Account_G_trending_Sideways: string;
    export default Account_G_trending_Sideways;
}