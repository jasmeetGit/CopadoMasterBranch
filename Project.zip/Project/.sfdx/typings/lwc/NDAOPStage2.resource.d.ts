declare module "@salesforce/resourceUrl/NDAOPStage2" {
    var NDAOPStage2: string;
    export default NDAOPStage2;
}