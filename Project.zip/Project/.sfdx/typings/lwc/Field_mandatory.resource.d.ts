declare module "@salesforce/resourceUrl/Field_mandatory" {
    var Field_mandatory: string;
    export default Field_mandatory;
}