declare module "@salesforce/resourceUrl/NDAOP3b" {
    var NDAOP3b: string;
    export default NDAOP3b;
}