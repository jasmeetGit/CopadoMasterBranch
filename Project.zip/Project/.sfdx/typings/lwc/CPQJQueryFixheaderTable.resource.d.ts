declare module "@salesforce/resourceUrl/CPQJQueryFixheaderTable" {
    var CPQJQueryFixheaderTable: string;
    export default CPQJQueryFixheaderTable;
}