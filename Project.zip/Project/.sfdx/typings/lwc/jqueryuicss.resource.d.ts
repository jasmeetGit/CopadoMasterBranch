declare module "@salesforce/resourceUrl/jqueryuicss" {
    var jqueryuicss: string;
    export default jqueryuicss;
}