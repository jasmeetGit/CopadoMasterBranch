declare module "@salesforce/resourceUrl/GBC_Stage_Cancelled" {
    var GBC_Stage_Cancelled: string;
    export default GBC_Stage_Cancelled;
}