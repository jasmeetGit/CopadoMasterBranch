declare module "@salesforce/resourceUrl/Other_Party_Stage_6a" {
    var Other_Party_Stage_6a: string;
    export default Other_Party_Stage_6a;
}