declare module "@salesforce/resourceUrl/NDAStdStage3a" {
    var NDAStdStage3a: string;
    export default NDAStdStage3a;
}