declare module "@salesforce/resourceUrl/NDAOP6a" {
    var NDAOP6a: string;
    export default NDAOP6a;
}