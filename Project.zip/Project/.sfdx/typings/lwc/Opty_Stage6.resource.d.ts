declare module "@salesforce/resourceUrl/Opty_Stage6" {
    var Opty_Stage6: string;
    export default Opty_Stage6;
}