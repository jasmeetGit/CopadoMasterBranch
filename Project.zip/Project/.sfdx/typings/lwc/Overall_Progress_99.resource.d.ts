declare module "@salesforce/resourceUrl/Overall_Progress_99" {
    var Overall_Progress_99: string;
    export default Overall_Progress_99;
}