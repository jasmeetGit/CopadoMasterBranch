declare module "@salesforce/resourceUrl/Multi_Source_Tapeout_Step1" {
    var Multi_Source_Tapeout_Step1: string;
    export default Multi_Source_Tapeout_Step1;
}