declare module "@salesforce/resourceUrl/MultiParty_Stage_6b" {
    var MultiParty_Stage_6b: string;
    export default MultiParty_Stage_6b;
}