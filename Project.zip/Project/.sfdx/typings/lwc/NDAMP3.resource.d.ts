declare module "@salesforce/resourceUrl/NDAMP3" {
    var NDAMP3: string;
    export default NDAMP3;
}