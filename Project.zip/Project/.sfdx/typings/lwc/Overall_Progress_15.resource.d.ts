declare module "@salesforce/resourceUrl/Overall_Progress_15" {
    var Overall_Progress_15: string;
    export default Overall_Progress_15;
}