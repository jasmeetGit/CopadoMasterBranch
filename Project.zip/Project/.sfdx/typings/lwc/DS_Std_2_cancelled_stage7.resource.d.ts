declare module "@salesforce/resourceUrl/DS_Std_2_cancelled_stage7" {
    var DS_Std_2_cancelled_stage7: string;
    export default DS_Std_2_cancelled_stage7;
}