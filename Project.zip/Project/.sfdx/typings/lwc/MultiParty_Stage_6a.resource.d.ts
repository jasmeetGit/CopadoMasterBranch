declare module "@salesforce/resourceUrl/MultiParty_Stage_6a" {
    var MultiParty_Stage_6a: string;
    export default MultiParty_Stage_6a;
}