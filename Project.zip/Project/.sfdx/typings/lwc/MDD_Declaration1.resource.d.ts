declare module "@salesforce/resourceUrl/MDD_Declaration1" {
    var MDD_Declaration1: string;
    export default MDD_Declaration1;
}