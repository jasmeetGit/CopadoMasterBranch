declare module "@salesforce/resourceUrl/LotRequestS6of9" {
    var LotRequestS6of9: string;
    export default LotRequestS6of9;
}