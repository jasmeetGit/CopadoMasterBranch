declare module "@salesforce/resourceUrl/NDAStdStage1" {
    var NDAStdStage1: string;
    export default NDAStdStage1;
}