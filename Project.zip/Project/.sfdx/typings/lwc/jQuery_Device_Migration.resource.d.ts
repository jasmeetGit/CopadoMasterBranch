declare module "@salesforce/resourceUrl/jQuery_Device_Migration" {
    var jQuery_Device_Migration: string;
    export default jQuery_Device_Migration;
}