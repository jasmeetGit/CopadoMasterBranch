declare module "@salesforce/resourceUrl/NDAOPStage3a" {
    var NDAOPStage3a: string;
    export default NDAOPStage3a;
}