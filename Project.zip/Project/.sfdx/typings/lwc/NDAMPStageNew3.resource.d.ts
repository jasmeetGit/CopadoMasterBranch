declare module "@salesforce/resourceUrl/NDAMPStageNew3" {
    var NDAMPStageNew3: string;
    export default NDAMPStageNew3;
}