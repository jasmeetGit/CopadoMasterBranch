declare module "@salesforce/resourceUrl/NDAMPStage6" {
    var NDAMPStage6: string;
    export default NDAMPStage6;
}