declare module "@salesforce/resourceUrl/Overall_Progress_100" {
    var Overall_Progress_100: string;
    export default Overall_Progress_100;
}