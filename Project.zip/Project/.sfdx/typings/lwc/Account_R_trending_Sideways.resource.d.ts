declare module "@salesforce/resourceUrl/Account_R_trending_Sideways" {
    var Account_R_trending_Sideways: string;
    export default Account_R_trending_Sideways;
}