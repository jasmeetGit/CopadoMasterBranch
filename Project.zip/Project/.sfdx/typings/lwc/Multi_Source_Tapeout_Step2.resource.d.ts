declare module "@salesforce/resourceUrl/Multi_Source_Tapeout_Step2" {
    var Multi_Source_Tapeout_Step2: string;
    export default Multi_Source_Tapeout_Step2;
}