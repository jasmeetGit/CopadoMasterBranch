declare module "@salesforce/resourceUrl/DS_Multi_prepare_stage1" {
    var DS_Multi_prepare_stage1: string;
    export default DS_Multi_prepare_stage1;
}