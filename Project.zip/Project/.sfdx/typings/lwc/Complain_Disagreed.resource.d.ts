declare module "@salesforce/resourceUrl/Complain_Disagreed" {
    var Complain_Disagreed: string;
    export default Complain_Disagreed;
}