declare module "@salesforce/resourceUrl/DW_Progress_50" {
    var DW_Progress_50: string;
    export default DW_Progress_50;
}