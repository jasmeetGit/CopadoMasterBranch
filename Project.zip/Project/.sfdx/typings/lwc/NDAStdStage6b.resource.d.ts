declare module "@salesforce/resourceUrl/NDAStdStage6b" {
    var NDAStdStage6b: string;
    export default NDAStdStage6b;
}