declare module "@salesforce/resourceUrl/MPW_Reservation_User_Guide_Internal_User" {
    var MPW_Reservation_User_Guide_Internal_User: string;
    export default MPW_Reservation_User_Guide_Internal_User;
}