declare module "@salesforce/resourceUrl/npi" {
    var npi: string;
    export default npi;
}