declare module "@salesforce/resourceUrl/Polyimide" {
    var Polyimide: string;
    export default Polyimide;
}