declare module "@salesforce/resourceUrl/BnP_Route_Stop_Status" {
    var BnP_Route_Stop_Status: string;
    export default BnP_Route_Stop_Status;
}