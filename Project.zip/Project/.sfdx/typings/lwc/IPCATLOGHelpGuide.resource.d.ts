declare module "@salesforce/resourceUrl/IPCATLOGHelpGuide" {
    var IPCATLOGHelpGuide: string;
    export default IPCATLOGHelpGuide;
}