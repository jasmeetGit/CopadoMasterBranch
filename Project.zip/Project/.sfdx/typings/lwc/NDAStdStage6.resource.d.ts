declare module "@salesforce/resourceUrl/NDAStdStage6" {
    var NDAStdStage6: string;
    export default NDAStdStage6;
}