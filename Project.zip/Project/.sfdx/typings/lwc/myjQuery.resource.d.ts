declare module "@salesforce/resourceUrl/myjQuery" {
    var myjQuery: string;
    export default myjQuery;
}