declare module "@salesforce/resourceUrl/GreenPSP" {
    var GreenPSP: string;
    export default GreenPSP;
}