declare module "@salesforce/resourceUrl/NDAOPStage5" {
    var NDAOPStage5: string;
    export default NDAOPStage5;
}