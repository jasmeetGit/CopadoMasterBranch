declare module "@salesforce/resourceUrl/BnP_Route_Pause_Status" {
    var BnP_Route_Pause_Status: string;
    export default BnP_Route_Pause_Status;
}