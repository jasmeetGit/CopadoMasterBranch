declare module "@salesforce/resourceUrl/Final_Step_MultiParty_TD_NDA" {
    var Final_Step_MultiParty_TD_NDA: string;
    export default Final_Step_MultiParty_TD_NDA;
}