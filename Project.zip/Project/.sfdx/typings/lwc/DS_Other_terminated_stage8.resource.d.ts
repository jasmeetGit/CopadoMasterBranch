declare module "@salesforce/resourceUrl/DS_Other_terminated_stage8" {
    var DS_Other_terminated_stage8: string;
    export default DS_Other_terminated_stage8;
}