declare module "@salesforce/resourceUrl/Green_Down" {
    var Green_Down: string;
    export default Green_Down;
}