declare module "@salesforce/resourceUrl/CaseStatus_NewIco" {
    var CaseStatus_NewIco: string;
    export default CaseStatus_NewIco;
}