declare module "@salesforce/resourceUrl/ConfiguratorFlowFMS" {
    var ConfiguratorFlowFMS: string;
    export default ConfiguratorFlowFMS;
}