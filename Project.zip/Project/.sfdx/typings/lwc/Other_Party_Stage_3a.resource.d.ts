declare module "@salesforce/resourceUrl/Other_Party_Stage_3a" {
    var Other_Party_Stage_3a: string;
    export default Other_Party_Stage_3a;
}