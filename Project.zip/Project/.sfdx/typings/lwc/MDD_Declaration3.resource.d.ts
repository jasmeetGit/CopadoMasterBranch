declare module "@salesforce/resourceUrl/MDD_Declaration3" {
    var MDD_Declaration3: string;
    export default MDD_Declaration3;
}