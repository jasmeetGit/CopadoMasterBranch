declare module "@salesforce/resourceUrl/NDAOPStage7" {
    var NDAOPStage7: string;
    export default NDAOPStage7;
}