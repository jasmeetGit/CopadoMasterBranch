declare module "@salesforce/resourceUrl/Button_Generate_PDF" {
    var Button_Generate_PDF: string;
    export default Button_Generate_PDF;
}