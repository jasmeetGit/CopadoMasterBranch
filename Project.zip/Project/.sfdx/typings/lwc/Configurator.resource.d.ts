declare module "@salesforce/resourceUrl/Configurator" {
    var Configurator: string;
    export default Configurator;
}