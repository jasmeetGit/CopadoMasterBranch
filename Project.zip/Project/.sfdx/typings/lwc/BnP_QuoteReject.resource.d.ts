declare module "@salesforce/resourceUrl/BnP_QuoteReject" {
    var BnP_QuoteReject: string;
    export default BnP_QuoteReject;
}