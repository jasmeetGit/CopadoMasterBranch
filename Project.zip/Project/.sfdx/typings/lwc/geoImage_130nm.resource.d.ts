declare module "@salesforce/resourceUrl/geoImage_130nm" {
    var geoImage_130nm: string;
    export default geoImage_130nm;
}