declare module "@salesforce/resourceUrl/Other_Party_Stage_4" {
    var Other_Party_Stage_4: string;
    export default Other_Party_Stage_4;
}