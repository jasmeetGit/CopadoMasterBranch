declare module "@salesforce/resourceUrl/GBC_Stage_New" {
    var GBC_Stage_New: string;
    export default GBC_Stage_New;
}