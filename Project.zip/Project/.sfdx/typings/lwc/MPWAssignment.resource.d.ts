declare module "@salesforce/resourceUrl/MPWAssignment" {
    var MPWAssignment: string;
    export default MPWAssignment;
}