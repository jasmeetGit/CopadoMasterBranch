declare module "@salesforce/resourceUrl/PDKALERTImage" {
    var PDKALERTImage: string;
    export default PDKALERTImage;
}