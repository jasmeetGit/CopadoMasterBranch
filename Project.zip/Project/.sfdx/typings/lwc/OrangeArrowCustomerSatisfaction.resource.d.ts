declare module "@salesforce/resourceUrl/OrangeArrowCustomerSatisfaction" {
    var OrangeArrowCustomerSatisfaction: string;
    export default OrangeArrowCustomerSatisfaction;
}