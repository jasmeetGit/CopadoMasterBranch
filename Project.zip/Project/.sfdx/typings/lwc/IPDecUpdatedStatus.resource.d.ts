declare module "@salesforce/resourceUrl/IPDecUpdatedStatus" {
    var IPDecUpdatedStatus: string;
    export default IPDecUpdatedStatus;
}