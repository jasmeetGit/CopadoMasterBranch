declare module "@salesforce/resourceUrl/Dot_M" {
    var Dot_M: string;
    export default Dot_M;
}