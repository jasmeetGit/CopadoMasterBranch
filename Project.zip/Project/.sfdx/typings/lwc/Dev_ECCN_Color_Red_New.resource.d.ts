declare module "@salesforce/resourceUrl/Dev_ECCN_Color_Red_New" {
    var Dev_ECCN_Color_Red_New: string;
    export default Dev_ECCN_Color_Red_New;
}