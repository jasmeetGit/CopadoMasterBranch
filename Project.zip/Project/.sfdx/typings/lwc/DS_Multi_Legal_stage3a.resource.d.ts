declare module "@salesforce/resourceUrl/DS_Multi_Legal_stage3a" {
    var DS_Multi_Legal_stage3a: string;
    export default DS_Multi_Legal_stage3a;
}