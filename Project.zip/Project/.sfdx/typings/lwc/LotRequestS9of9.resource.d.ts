declare module "@salesforce/resourceUrl/LotRequestS9of9" {
    var LotRequestS9of9: string;
    export default LotRequestS9of9;
}