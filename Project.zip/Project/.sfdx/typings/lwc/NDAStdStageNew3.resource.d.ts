declare module "@salesforce/resourceUrl/NDAStdStageNew3" {
    var NDAStdStageNew3: string;
    export default NDAStdStageNew3;
}