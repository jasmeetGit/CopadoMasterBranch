declare module "@salesforce/resourceUrl/JqueryDatatableCSS" {
    var JqueryDatatableCSS: string;
    export default JqueryDatatableCSS;
}