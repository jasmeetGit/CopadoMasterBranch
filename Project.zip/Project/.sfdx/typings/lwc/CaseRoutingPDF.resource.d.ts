declare module "@salesforce/resourceUrl/CaseRoutingPDF" {
    var CaseRoutingPDF: string;
    export default CaseRoutingPDF;
}