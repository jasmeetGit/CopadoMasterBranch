declare module "@salesforce/resourceUrl/CaseStatus_Reopen" {
    var CaseStatus_Reopen: string;
    export default CaseStatus_Reopen;
}