declare module "@salesforce/resourceUrl/NDAMP5" {
    var NDAMP5: string;
    export default NDAMP5;
}