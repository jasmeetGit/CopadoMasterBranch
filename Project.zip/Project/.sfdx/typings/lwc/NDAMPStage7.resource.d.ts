declare module "@salesforce/resourceUrl/NDAMPStage7" {
    var NDAMPStage7: string;
    export default NDAMPStage7;
}