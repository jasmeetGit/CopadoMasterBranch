declare module "@salesforce/resourceUrl/LotRequestS4of9" {
    var LotRequestS4of9: string;
    export default LotRequestS4of9;
}