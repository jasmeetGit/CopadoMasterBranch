declare module "@salesforce/resourceUrl/Expired_Multi_Party_GEN_NDA" {
    var Expired_Multi_Party_GEN_NDA: string;
    export default Expired_Multi_Party_GEN_NDA;
}