declare module "@salesforce/resourceUrl/Other_Party_Stage_5" {
    var Other_Party_Stage_5: string;
    export default Other_Party_Stage_5;
}