declare module "@salesforce/resourceUrl/FMS_SP_Images" {
    var FMS_SP_Images: string;
    export default FMS_SP_Images;
}