declare module "@salesforce/resourceUrl/Dot_Y" {
    var Dot_Y: string;
    export default Dot_Y;
}