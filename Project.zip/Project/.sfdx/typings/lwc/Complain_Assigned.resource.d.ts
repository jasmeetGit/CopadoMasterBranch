declare module "@salesforce/resourceUrl/Complain_Assigned" {
    var Complain_Assigned: string;
    export default Complain_Assigned;
}