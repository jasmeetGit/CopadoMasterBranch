declare module "@salesforce/resourceUrl/jstreejs" {
    var jstreejs: string;
    export default jstreejs;
}