declare module "@salesforce/resourceUrl/jqueryblockUI" {
    var jqueryblockUI: string;
    export default jqueryblockUI;
}