declare module "@salesforce/resourceUrl/Customize_Configurator_Plus" {
    var Customize_Configurator_Plus: string;
    export default Customize_Configurator_Plus;
}