declare module "@salesforce/resourceUrl/DS_Multi_activate_stage6" {
    var DS_Multi_activate_stage6: string;
    export default DS_Multi_activate_stage6;
}