declare module "@salesforce/resourceUrl/LogoOverride" {
    var LogoOverride: string;
    export default LogoOverride;
}