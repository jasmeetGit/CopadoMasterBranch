declare module "@salesforce/resourceUrl/Overall_Progress_75" {
    var Overall_Progress_75: string;
    export default Overall_Progress_75;
}