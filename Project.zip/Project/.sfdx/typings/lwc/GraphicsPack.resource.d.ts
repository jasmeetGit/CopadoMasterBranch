declare module "@salesforce/resourceUrl/GraphicsPack" {
    var GraphicsPack: string;
    export default GraphicsPack;
}