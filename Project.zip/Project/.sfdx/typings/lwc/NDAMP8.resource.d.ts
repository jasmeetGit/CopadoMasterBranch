declare module "@salesforce/resourceUrl/NDAMP8" {
    var NDAMP8: string;
    export default NDAMP8;
}