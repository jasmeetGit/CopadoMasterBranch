declare module "@salesforce/resourceUrl/NDAMPStage4" {
    var NDAMPStage4: string;
    export default NDAMPStage4;
}