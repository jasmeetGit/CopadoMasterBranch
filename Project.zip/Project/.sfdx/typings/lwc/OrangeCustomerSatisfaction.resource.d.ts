declare module "@salesforce/resourceUrl/OrangeCustomerSatisfaction" {
    var OrangeCustomerSatisfaction: string;
    export default OrangeCustomerSatisfaction;
}