declare module "@salesforce/resourceUrl/LotRequestS7of9" {
    var LotRequestS7of9: string;
    export default LotRequestS7of9;
}