declare module "@salesforce/resourceUrl/contact_lookup_icon" {
    var contact_lookup_icon: string;
    export default contact_lookup_icon;
}