declare module "@salesforce/resourceUrl/Account_R_trending_Down" {
    var Account_R_trending_Down: string;
    export default Account_R_trending_Down;
}