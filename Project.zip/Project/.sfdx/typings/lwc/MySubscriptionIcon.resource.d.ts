declare module "@salesforce/resourceUrl/MySubscriptionIcon" {
    var MySubscriptionIcon: string;
    export default MySubscriptionIcon;
}