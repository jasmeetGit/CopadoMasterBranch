declare module "@salesforce/resourceUrl/MultiParty_Stage_1" {
    var MultiParty_Stage_1: string;
    export default MultiParty_Stage_1;
}