declare module "@salesforce/resourceUrl/CustomerNameChangeUpload" {
    var CustomerNameChangeUpload: string;
    export default CustomerNameChangeUpload;
}