declare module "@salesforce/resourceUrl/NDAStdStage2R1" {
    var NDAStdStage2R1: string;
    export default NDAStdStage2R1;
}