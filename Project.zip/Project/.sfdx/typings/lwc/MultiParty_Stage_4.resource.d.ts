declare module "@salesforce/resourceUrl/MultiParty_Stage_4" {
    var MultiParty_Stage_4: string;
    export default MultiParty_Stage_4;
}