declare module "@salesforce/resourceUrl/GBC_Stage_Approved" {
    var GBC_Stage_Approved: string;
    export default GBC_Stage_Approved;
}