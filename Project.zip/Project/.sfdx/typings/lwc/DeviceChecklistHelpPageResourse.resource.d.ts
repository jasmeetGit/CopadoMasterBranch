declare module "@salesforce/resourceUrl/DeviceChecklistHelpPageResourse" {
    var DeviceChecklistHelpPageResourse: string;
    export default DeviceChecklistHelpPageResourse;
}