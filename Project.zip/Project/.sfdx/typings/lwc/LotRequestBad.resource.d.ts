declare module "@salesforce/resourceUrl/LotRequestBad" {
    var LotRequestBad: string;
    export default LotRequestBad;
}