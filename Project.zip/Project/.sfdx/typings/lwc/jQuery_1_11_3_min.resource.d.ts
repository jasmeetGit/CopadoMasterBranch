declare module "@salesforce/resourceUrl/jQuery_1_11_3_min" {
    var jQuery_1_11_3_min: string;
    export default jQuery_1_11_3_min;
}