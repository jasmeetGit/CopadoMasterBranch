declare module "@salesforce/resourceUrl/img32px" {
    var img32px: string;
    export default img32px;
}