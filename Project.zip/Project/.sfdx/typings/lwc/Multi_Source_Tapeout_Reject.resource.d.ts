declare module "@salesforce/resourceUrl/Multi_Source_Tapeout_Reject" {
    var Multi_Source_Tapeout_Reject: string;
    export default Multi_Source_Tapeout_Reject;
}