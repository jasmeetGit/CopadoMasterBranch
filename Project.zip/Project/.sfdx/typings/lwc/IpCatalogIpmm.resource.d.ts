declare module "@salesforce/resourceUrl/IpCatalogIpmm" {
    var IpCatalogIpmm: string;
    export default IpCatalogIpmm;
}