declare module "@salesforce/resourceUrl/Opty_Stage2" {
    var Opty_Stage2: string;
    export default Opty_Stage2;
}