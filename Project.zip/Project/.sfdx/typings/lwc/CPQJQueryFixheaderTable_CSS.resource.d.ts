declare module "@salesforce/resourceUrl/CPQJQueryFixheaderTable_CSS" {
    var CPQJQueryFixheaderTable_CSS: string;
    export default CPQJQueryFixheaderTable_CSS;
}