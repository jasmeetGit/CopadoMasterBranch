declare module "@salesforce/resourceUrl/MDD_Declaration2" {
    var MDD_Declaration2: string;
    export default MDD_Declaration2;
}