declare module "@salesforce/resourceUrl/modalJS" {
    var modalJS: string;
    export default modalJS;
}