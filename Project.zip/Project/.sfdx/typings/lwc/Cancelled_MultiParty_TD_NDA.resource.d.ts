declare module "@salesforce/resourceUrl/Cancelled_MultiParty_TD_NDA" {
    var Cancelled_MultiParty_TD_NDA: string;
    export default Cancelled_MultiParty_TD_NDA;
}