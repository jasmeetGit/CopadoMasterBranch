declare module "@salesforce/resourceUrl/NDAOPStage6b" {
    var NDAOPStage6b: string;
    export default NDAOPStage6b;
}