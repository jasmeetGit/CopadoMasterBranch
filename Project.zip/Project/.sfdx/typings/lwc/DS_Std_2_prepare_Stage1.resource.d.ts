declare module "@salesforce/resourceUrl/DS_Std_2_prepare_Stage1" {
    var DS_Std_2_prepare_Stage1: string;
    export default DS_Std_2_prepare_Stage1;
}