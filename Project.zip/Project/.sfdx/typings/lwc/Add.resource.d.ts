declare module "@salesforce/resourceUrl/Add" {
    var Add: string;
    export default Add;
}