declare module "@salesforce/resourceUrl/GFHeaderResources" {
    var GFHeaderResources: string;
    export default GFHeaderResources;
}