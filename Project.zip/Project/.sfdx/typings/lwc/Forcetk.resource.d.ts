declare module "@salesforce/resourceUrl/Forcetk" {
    var Forcetk: string;
    export default Forcetk;
}