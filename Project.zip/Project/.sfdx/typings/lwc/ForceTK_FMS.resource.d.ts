declare module "@salesforce/resourceUrl/ForceTK_FMS" {
    var ForceTK_FMS: string;
    export default ForceTK_FMS;
}