declare module "@salesforce/resourceUrl/NDAOP1" {
    var NDAOP1: string;
    export default NDAOP1;
}