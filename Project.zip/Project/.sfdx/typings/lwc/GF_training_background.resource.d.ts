declare module "@salesforce/resourceUrl/GF_training_background" {
    var GF_training_background: string;
    export default GF_training_background;
}