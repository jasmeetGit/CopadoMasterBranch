declare module "@salesforce/resourceUrl/DS_Std_2_expired_stage6b" {
    var DS_Std_2_expired_stage6b: string;
    export default DS_Std_2_expired_stage6b;
}