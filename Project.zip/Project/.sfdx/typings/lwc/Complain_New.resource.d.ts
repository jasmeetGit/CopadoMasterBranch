declare module "@salesforce/resourceUrl/Complain_New" {
    var Complain_New: string;
    export default Complain_New;
}