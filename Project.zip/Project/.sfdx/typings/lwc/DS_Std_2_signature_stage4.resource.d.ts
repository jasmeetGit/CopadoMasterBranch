declare module "@salesforce/resourceUrl/DS_Std_2_signature_stage4" {
    var DS_Std_2_signature_stage4: string;
    export default DS_Std_2_signature_stage4;
}