declare module "@salesforce/resourceUrl/PDKOKImage" {
    var PDKOKImage: string;
    export default PDKOKImage;
}