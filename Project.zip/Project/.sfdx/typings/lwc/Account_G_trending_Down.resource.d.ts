declare module "@salesforce/resourceUrl/Account_G_trending_Down" {
    var Account_G_trending_Down: string;
    export default Account_G_trending_Down;
}