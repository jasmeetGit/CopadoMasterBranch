declare module "@salesforce/resourceUrl/NDAMP7" {
    var NDAMP7: string;
    export default NDAMP7;
}