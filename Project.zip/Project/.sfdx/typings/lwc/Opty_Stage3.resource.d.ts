declare module "@salesforce/resourceUrl/Opty_Stage3" {
    var Opty_Stage3: string;
    export default Opty_Stage3;
}