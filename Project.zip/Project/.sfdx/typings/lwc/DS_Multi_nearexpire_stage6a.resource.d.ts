declare module "@salesforce/resourceUrl/DS_Multi_nearexpire_stage6a" {
    var DS_Multi_nearexpire_stage6a: string;
    export default DS_Multi_nearexpire_stage6a;
}