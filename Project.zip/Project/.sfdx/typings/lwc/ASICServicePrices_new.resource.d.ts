declare module "@salesforce/resourceUrl/ASICServicePrices_new" {
    var ASICServicePrices_new: string;
    export default ASICServicePrices_new;
}