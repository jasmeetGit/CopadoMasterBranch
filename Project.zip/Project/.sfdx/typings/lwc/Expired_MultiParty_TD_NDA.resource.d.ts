declare module "@salesforce/resourceUrl/Expired_MultiParty_TD_NDA" {
    var Expired_MultiParty_TD_NDA: string;
    export default Expired_MultiParty_TD_NDA;
}