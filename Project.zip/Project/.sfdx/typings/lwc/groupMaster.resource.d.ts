declare module "@salesforce/resourceUrl/groupMaster" {
    var groupMaster: string;
    export default groupMaster;
}