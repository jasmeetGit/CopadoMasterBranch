declare module "@salesforce/resourceUrl/NDAStd7" {
    var NDAStd7: string;
    export default NDAStd7;
}