declare module "@salesforce/resourceUrl/GraphicsPackExample" {
    var GraphicsPackExample: string;
    export default GraphicsPackExample;
}