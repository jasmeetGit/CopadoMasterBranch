declare module "@salesforce/resourceUrl/atlasresource" {
    var atlasresource: string;
    export default atlasresource;
}