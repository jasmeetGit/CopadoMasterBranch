declare module "@salesforce/resourceUrl/geoImage_14nm" {
    var geoImage_14nm: string;
    export default geoImage_14nm;
}