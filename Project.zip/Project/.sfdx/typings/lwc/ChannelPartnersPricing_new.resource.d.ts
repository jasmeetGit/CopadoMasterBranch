declare module "@salesforce/resourceUrl/ChannelPartnersPricing_new" {
    var ChannelPartnersPricing_new: string;
    export default ChannelPartnersPricing_new;
}