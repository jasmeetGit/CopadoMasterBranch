declare module "@salesforce/resourceUrl/geoImage_180nm" {
    var geoImage_180nm: string;
    export default geoImage_180nm;
}