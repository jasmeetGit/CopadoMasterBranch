declare module "@salesforce/resourceUrl/NDAMP6a" {
    var NDAMP6a: string;
    export default NDAMP6a;
}