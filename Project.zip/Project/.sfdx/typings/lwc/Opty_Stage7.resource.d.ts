declare module "@salesforce/resourceUrl/Opty_Stage7" {
    var Opty_Stage7: string;
    export default Opty_Stage7;
}