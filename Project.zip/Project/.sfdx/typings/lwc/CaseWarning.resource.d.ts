declare module "@salesforce/resourceUrl/CaseWarning" {
    var CaseWarning: string;
    export default CaseWarning;
}