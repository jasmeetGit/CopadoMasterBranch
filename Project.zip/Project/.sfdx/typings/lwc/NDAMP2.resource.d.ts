declare module "@salesforce/resourceUrl/NDAMP2" {
    var NDAMP2: string;
    export default NDAMP2;
}