declare module "@salesforce/resourceUrl/DWC" {
    var DWC: string;
    export default DWC;
}