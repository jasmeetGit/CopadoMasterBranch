declare module "@salesforce/resourceUrl/DS_Multi_ready_stage5" {
    var DS_Multi_ready_stage5: string;
    export default DS_Multi_ready_stage5;
}