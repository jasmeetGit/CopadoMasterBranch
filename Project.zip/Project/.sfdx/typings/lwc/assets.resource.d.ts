declare module "@salesforce/resourceUrl/assets" {
    var assets: string;
    export default assets;
}