declare module "@salesforce/resourceUrl/geoImage_20nm" {
    var geoImage_20nm: string;
    export default geoImage_20nm;
}