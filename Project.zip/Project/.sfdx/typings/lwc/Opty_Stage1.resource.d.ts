declare module "@salesforce/resourceUrl/Opty_Stage1" {
    var Opty_Stage1: string;
    export default Opty_Stage1;
}