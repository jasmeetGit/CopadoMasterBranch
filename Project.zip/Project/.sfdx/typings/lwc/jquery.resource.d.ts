declare module "@salesforce/resourceUrl/jquery" {
    var jquery: string;
    export default jquery;
}