declare module "@salesforce/resourceUrl/NDAOPStage6" {
    var NDAOPStage6: string;
    export default NDAOPStage6;
}