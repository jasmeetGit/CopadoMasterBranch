declare module "@salesforce/resourceUrl/NDAStdStage1a" {
    var NDAStdStage1a: string;
    export default NDAStdStage1a;
}