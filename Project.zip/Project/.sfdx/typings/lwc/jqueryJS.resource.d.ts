declare module "@salesforce/resourceUrl/jqueryJS" {
    var jqueryJS: string;
    export default jqueryJS;
}