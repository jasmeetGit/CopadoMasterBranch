declare module "@salesforce/resourceUrl/CustomerReport_StandardSubscription_jquery224" {
    var CustomerReport_StandardSubscription_jquery224: string;
    export default CustomerReport_StandardSubscription_jquery224;
}