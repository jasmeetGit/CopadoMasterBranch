declare module "@salesforce/resourceUrl/Opty_Stage0" {
    var Opty_Stage0: string;
    export default Opty_Stage0;
}