declare module "@salesforce/resourceUrl/NDAMPStage1" {
    var NDAMPStage1: string;
    export default NDAMPStage1;
}