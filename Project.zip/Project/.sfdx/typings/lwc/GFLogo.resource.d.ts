declare module "@salesforce/resourceUrl/GFLogo" {
    var GFLogo: string;
    export default GFLogo;
}