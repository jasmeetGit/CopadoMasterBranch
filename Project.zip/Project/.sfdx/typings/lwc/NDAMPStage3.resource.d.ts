declare module "@salesforce/resourceUrl/NDAMPStage3" {
    var NDAMPStage3: string;
    export default NDAMPStage3;
}