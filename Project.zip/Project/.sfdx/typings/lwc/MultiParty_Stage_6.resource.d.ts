declare module "@salesforce/resourceUrl/MultiParty_Stage_6" {
    var MultiParty_Stage_6: string;
    export default MultiParty_Stage_6;
}