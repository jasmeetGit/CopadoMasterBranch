declare module "@salesforce/resourceUrl/DRCLegends" {
    var DRCLegends: string;
    export default DRCLegends;
}