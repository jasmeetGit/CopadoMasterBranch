declare module "@salesforce/resourceUrl/DS_Multi_signature_stage4" {
    var DS_Multi_signature_stage4: string;
    export default DS_Multi_signature_stage4;
}