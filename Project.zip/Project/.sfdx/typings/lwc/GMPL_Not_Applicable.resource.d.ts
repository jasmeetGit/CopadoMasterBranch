declare module "@salesforce/resourceUrl/GMPL_Not_Applicable" {
    var GMPL_Not_Applicable: string;
    export default GMPL_Not_Applicable;
}