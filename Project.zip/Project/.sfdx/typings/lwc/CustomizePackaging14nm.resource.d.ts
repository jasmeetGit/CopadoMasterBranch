declare module "@salesforce/resourceUrl/CustomizePackaging14nm" {
    var CustomizePackaging14nm: string;
    export default CustomizePackaging14nm;
}