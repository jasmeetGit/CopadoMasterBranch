declare module "@salesforce/resourceUrl/Complain_Resolv" {
    var Complain_Resolv: string;
    export default Complain_Resolv;
}