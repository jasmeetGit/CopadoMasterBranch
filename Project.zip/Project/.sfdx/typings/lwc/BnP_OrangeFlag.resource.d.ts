declare module "@salesforce/resourceUrl/BnP_OrangeFlag" {
    var BnP_OrangeFlag: string;
    export default BnP_OrangeFlag;
}