declare module "@salesforce/resourceUrl/GMPL_Full_Support" {
    var GMPL_Full_Support: string;
    export default GMPL_Full_Support;
}