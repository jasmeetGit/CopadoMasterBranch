declare module "@salesforce/resourceUrl/GreenLight" {
    var GreenLight: string;
    export default GreenLight;
}