declare module "@salesforce/resourceUrl/CE_Weekly_CSS" {
    var CE_Weekly_CSS: string;
    export default CE_Weekly_CSS;
}