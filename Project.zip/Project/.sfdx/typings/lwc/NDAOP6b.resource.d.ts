declare module "@salesforce/resourceUrl/NDAOP6b" {
    var NDAOP6b: string;
    export default NDAOP6b;
}