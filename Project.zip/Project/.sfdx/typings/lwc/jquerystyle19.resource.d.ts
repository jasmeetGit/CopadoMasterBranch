declare module "@salesforce/resourceUrl/jquerystyle19" {
    var jquerystyle19: string;
    export default jquerystyle19;
}