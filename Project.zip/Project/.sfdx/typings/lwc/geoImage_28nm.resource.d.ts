declare module "@salesforce/resourceUrl/geoImage_28nm" {
    var geoImage_28nm: string;
    export default geoImage_28nm;
}