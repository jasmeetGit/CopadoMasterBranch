declare module "@salesforce/resourceUrl/NDAMPStage5" {
    var NDAMPStage5: string;
    export default NDAMPStage5;
}