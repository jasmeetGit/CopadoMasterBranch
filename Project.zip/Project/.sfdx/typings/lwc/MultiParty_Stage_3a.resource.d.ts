declare module "@salesforce/resourceUrl/MultiParty_Stage_3a" {
    var MultiParty_Stage_3a: string;
    export default MultiParty_Stage_3a;
}