declare module "@salesforce/resourceUrl/Configurator_Backtrack" {
    var Configurator_Backtrack: string;
    export default Configurator_Backtrack;
}