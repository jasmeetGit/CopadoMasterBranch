declare module "@salesforce/resourceUrl/MDD_DeclarationBack" {
    var MDD_DeclarationBack: string;
    export default MDD_DeclarationBack;
}