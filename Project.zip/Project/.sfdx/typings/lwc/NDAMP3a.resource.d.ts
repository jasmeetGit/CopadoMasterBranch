declare module "@salesforce/resourceUrl/NDAMP3a" {
    var NDAMP3a: string;
    export default NDAMP3a;
}