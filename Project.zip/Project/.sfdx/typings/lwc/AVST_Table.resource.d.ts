declare module "@salesforce/resourceUrl/AVST_Table" {
    var AVST_Table: string;
    export default AVST_Table;
}