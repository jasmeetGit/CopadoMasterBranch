declare module "@salesforce/resourceUrl/Near_Expire_GN_NDA" {
    var Near_Expire_GN_NDA: string;
    export default Near_Expire_GN_NDA;
}