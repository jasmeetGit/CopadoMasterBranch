declare module "@salesforce/resourceUrl/NDAOP7" {
    var NDAOP7: string;
    export default NDAOP7;
}