declare module "@salesforce/resourceUrl/NDAStd4" {
    var NDAStd4: string;
    export default NDAStd4;
}