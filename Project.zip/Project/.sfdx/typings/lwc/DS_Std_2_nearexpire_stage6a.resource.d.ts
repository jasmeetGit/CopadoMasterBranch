declare module "@salesforce/resourceUrl/DS_Std_2_nearexpire_stage6a" {
    var DS_Std_2_nearexpire_stage6a: string;
    export default DS_Std_2_nearexpire_stage6a;
}