declare module "@salesforce/resourceUrl/JS_ROSVF_eucConLookup" {
    var JS_ROSVF_eucConLookup: string;
    export default JS_ROSVF_eucConLookup;
}