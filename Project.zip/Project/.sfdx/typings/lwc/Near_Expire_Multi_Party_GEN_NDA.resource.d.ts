declare module "@salesforce/resourceUrl/Near_Expire_Multi_Party_GEN_NDA" {
    var Near_Expire_Multi_Party_GEN_NDA: string;
    export default Near_Expire_Multi_Party_GEN_NDA;
}