declare module "@salesforce/resourceUrl/JqueryDatatable" {
    var JqueryDatatable: string;
    export default JqueryDatatable;
}