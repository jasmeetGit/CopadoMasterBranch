declare module "@salesforce/resourceUrl/MultiParty_Stage_7" {
    var MultiParty_Stage_7: string;
    export default MultiParty_Stage_7;
}