declare module "@salesforce/resourceUrl/LotRequestS5of9" {
    var LotRequestS5of9: string;
    export default LotRequestS5of9;
}