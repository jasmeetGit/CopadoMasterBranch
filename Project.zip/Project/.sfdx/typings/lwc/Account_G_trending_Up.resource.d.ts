declare module "@salesforce/resourceUrl/Account_G_trending_Up" {
    var Account_G_trending_Up: string;
    export default Account_G_trending_Up;
}