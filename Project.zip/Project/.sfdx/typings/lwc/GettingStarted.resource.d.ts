declare module "@salesforce/resourceUrl/GettingStarted" {
    var GettingStarted: string;
    export default GettingStarted;
}