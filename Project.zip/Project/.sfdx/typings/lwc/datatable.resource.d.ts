declare module "@salesforce/resourceUrl/datatable" {
    var datatable: string;
    export default datatable;
}