declare module "@salesforce/resourceUrl/Dot_R3" {
    var Dot_R3: string;
    export default Dot_R3;
}