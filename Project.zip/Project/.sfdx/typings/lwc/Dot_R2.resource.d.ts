declare module "@salesforce/resourceUrl/Dot_R2" {
    var Dot_R2: string;
    export default Dot_R2;
}