declare module "@salesforce/resourceUrl/Account_R_trending_Up" {
    var Account_R_trending_Up: string;
    export default Account_R_trending_Up;
}