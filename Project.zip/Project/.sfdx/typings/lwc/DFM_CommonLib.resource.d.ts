declare module "@salesforce/resourceUrl/DFM_CommonLib" {
    var DFM_CommonLib: string;
    export default DFM_CommonLib;
}