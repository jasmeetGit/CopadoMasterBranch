declare module "@salesforce/resourceUrl/InformationUpdate" {
    var InformationUpdate: string;
    export default InformationUpdate;
}