declare module "@salesforce/resourceUrl/Activated_MultiParty_TD_NDA" {
    var Activated_MultiParty_TD_NDA: string;
    export default Activated_MultiParty_TD_NDA;
}