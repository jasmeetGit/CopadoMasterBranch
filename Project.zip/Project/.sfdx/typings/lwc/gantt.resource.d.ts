declare module "@salesforce/resourceUrl/gantt" {
    var gantt: string;
    export default gantt;
}