declare module "@salesforce/resourceUrl/OppCPQuestStatus" {
    var OppCPQuestStatus: string;
    export default OppCPQuestStatus;
}