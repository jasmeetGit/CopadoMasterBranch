declare module "@salesforce/resourceUrl/NDAStd6b" {
    var NDAStd6b: string;
    export default NDAStd6b;
}