declare module "@salesforce/resourceUrl/Opty_Stage8" {
    var Opty_Stage8: string;
    export default Opty_Stage8;
}