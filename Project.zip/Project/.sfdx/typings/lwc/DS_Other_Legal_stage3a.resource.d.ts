declare module "@salesforce/resourceUrl/DS_Other_Legal_stage3a" {
    var DS_Other_Legal_stage3a: string;
    export default DS_Other_Legal_stage3a;
}